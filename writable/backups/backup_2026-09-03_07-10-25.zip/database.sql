-- MySQL dump 10.13  Distrib 5.7.44, for Linux (x86_64)
--
-- Host: db002767.mydbserver.com    Database: usr_p482496_5
-- ------------------------------------------------------
-- Server version	8.4.8-8

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `articles`
--

DROP TABLE IF EXISTS `articles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `articles` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `article_number` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `price_cents` mediumint NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `note` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `meta` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `article_number` (`article_number`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `articles`
--

LOCK TABLES `articles` WRITE;
/*!40000 ALTER TABLE `articles` DISABLE KEYS */;
INSERT INTO `articles` VALUES (1,'mbb24-hosting','Anteilige Hostinggebühr, alle erforderlichen monatlichen Arbeiten, im Zusammenhang mit der Webseite! Jedoch ohne größere Änderungen, diese müssen separat berechnet werden.',8845,1,'vierteljährlich',NULL,'2026-07-06 10:23:15','2026-07-06 10:23:15'),(2,'mbb24-domain','Jährliche Domainkosten für mbb-24.de',240,1,NULL,NULL,'2026-07-06 10:23:15','2026-07-06 10:23:15'),(3,'mbb24-sicherheit','Sicherheitspaket gemäß E-Mail:Upgrade CMS - System (Joomla6): 95€Impressum & Datenschutz: 77€',17200,0,'einmalig 2026',NULL,'2026-07-06 10:23:15','2026-07-06 17:00:09'),(4,'mbb24-sicherheit-jährlich','Aktualisierung von Impressum &amp; Datenschutz, wenn erforderlich\r\nGrundlage: Mein Abo bei Erecht24 als Basis\r\nKeine Rechtsberatung',1900,1,'NEU',NULL,'2026-07-06 10:23:15','2026-07-06 10:23:15'),(5,'silber-datensicherung','Monatliche Datensicherung mit Akeeba Backup\r\nPro, einschl. automatisierter Speicherung auf\r\nexterner deutscher Qloud (Hetzner)',995,1,'monatlich',NULL,'2026-07-06 10:23:15','2026-07-06 10:23:15'),(6,'silber-wartung','Joomla! Aktualisierungen nach Erfordernis,\r\nAktualisierungen von meinen Erweiterungen,\r\nwelche bei mir enthalten sind, JCE - Editor (ggf. Pro),\r\nAkeeba Backup (Pro),Template / Builder: Yootheme Pro\r\nBackupMonkey bis 31.12.2026 kostenlos',2150,1,'monatlich, ab 2027 +2€ für BM',NULL,'2026-07-06 10:23:15','2026-07-06 10:23:15'),(7,'ihrtaxi-domain','Jährliche Domainkosten für Endung .de (IhrTaxi-Hamburg.de)',2400,1,'(alt: 1,80/Monat)',NULL,'2026-07-06 10:23:15','2026-07-06 10:23:15'),(8,'ihrtaxi-email-postfach','Emailpostfach 3 Gigabyte, mit SPAM-Schutz und\r\nunendlich vielen Email- Adressen',6975,1,'jährlich (vorher 65,40)',NULL,'2026-07-06 10:23:15','2026-07-06 10:23:15'),(9,'ihrtaxi-programm','Updates und Pflege der Webseite, einschließlich\r\nDatensicherung (ohne Gewähr, Datensicherung ist per Hand)\r\nSpeicherung auf der Webseite &amp; bei Hetzner in externer deutscher Cloud',120,1,'jährlich (Preis bleibt konstant)',NULL,'2026-07-06 10:23:15','2026-07-06 10:23:15');
/*!40000 ALTER TABLE `articles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `creditors`
--

DROP TABLE IF EXISTS `creditors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `creditors` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `creditor_number` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `company_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `note` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `meta` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `creditor_number` (`creditor_number`),
  UNIQUE KEY `company_name_unique` (`company_name`),
  KEY `company_name` (`company_name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `creditors`
--

LOCK TABLES `creditors` WRITE;
/*!40000 ALTER TABLE `creditors` DISABLE KEYS */;
INSERT INTO `creditors` VALUES (1,'388252','Mittwald',1,'Hoster',NULL,'2026-08-13 15:12:23','2026-08-24 08:19:25'),(2,'K0970955323','Hetzner Online GmbH',1,'Qloud-Speicher',NULL,'2026-08-20 16:34:09','2026-08-24 08:19:02'),(3,'8172165','Akeeba Ltd',1,'Datensicherung',NULL,'2026-08-21 05:00:35','2026-08-24 08:19:15'),(4,'08172165','Paddle (JCE)',1,NULL,NULL,'2026-08-29 11:55:58','2026-08-29 11:55:58'),(5,'DE260820446','Yootheme',1,NULL,NULL,'2026-08-29 11:57:58','2026-08-29 11:57:58'),(6,'B5450459','Digistore24 (eRecht24)',1,NULL,NULL,'2026-08-29 12:29:23','2026-08-29 12:29:23'),(7,'DE323248038','BackupMonkey UG',1,NULL,NULL,'2026-09-02 05:36:38','2026-09-02 05:36:38');
/*!40000 ALTER TABLE `creditors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `customer_number` bigint DEFAULT NULL,
  `company` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `first_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `last_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `street` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `postal_code` int NOT NULL,
  `city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'Hamburg',
  `phone` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `invoice_folder` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `note` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `meta` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_number` (`customer_number`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,10001,'Taxenbetrieb Frank Wiegmann','Frank','Wiegmann','Ellerneck 8e',22045,'Hamburg','','info@ihrtaxi-hamburg.de',NULL,'',1,NULL,'2026-07-06 10:23:15','2026-07-06 10:23:15'),(2,10015,'vo.lan.di','Volker','Lange','Lübecker Straße 10',39576,'Stendal','','volandi@freepasswort.de','volandi','Altes Notebook OFFLINE',1,NULL,'2026-07-06 10:23:15','2026-08-25 15:10:37'),(3,10006,'Malereibetrieb Björn Behnke GmbH','Björn','Behnke','Eulenkamp 2',22049,'Hamburg','','rechnung@mbb-24.de',NULL,'',1,NULL,'2026-07-06 10:23:15','2026-07-06 10:23:15'),(4,10014,'Reinhard Dreger e.K.','Reinhard','Dreger','Römeberg 9',21400,'Reinstorf OT Wendhausen','','info@silberring.info',NULL,'',1,NULL,'2026-07-06 10:23:15','2026-07-06 10:23:15');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `incoming_invoices`
--

DROP TABLE IF EXISTS `incoming_invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `incoming_invoices` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `creditor_id` int unsigned NOT NULL,
  `booking_year` smallint unsigned NOT NULL,
  `invoice_number` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `invoice_date` date NOT NULL,
  `amount_cents` int NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `creditor_id_invoice_number_booking_year` (`creditor_id`,`invoice_number`,`booking_year`),
  KEY `creditor_id` (`creditor_id`),
  KEY `booking_year` (`booking_year`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `incoming_invoices`
--

LOCK TABLES `incoming_invoices` WRITE;
/*!40000 ALTER TABLE `incoming_invoices` DISABLE KEYS */;
INSERT INTO `incoming_invoices` VALUES (1,2,2025,'086000156249','2025-02-19',762,'2026-08-20 16:34:09','2026-08-20 16:34:09'),(2,2,2025,'082000256707','2025-04-19',762,'2026-08-20 16:35:23','2026-08-20 16:35:23'),(3,2,2025,'08900040253','2025-06-19',762,'2026-08-20 16:36:06','2026-08-20 16:36:06'),(4,2,2025,'084000410769','2025-08-19',762,'2026-08-20 16:36:48','2026-08-20 16:36:48'),(5,2,2025,'085000573218','2025-10-19',762,'2026-08-20 16:37:29','2026-08-20 16:37:29'),(6,2,2025,'085000670931','2025-12-19',762,'2026-08-20 16:38:09','2026-08-20 16:38:09'),(7,2,2026,'080000740041','2026-02-19',762,'2026-08-21 04:50:47','2026-08-21 04:50:47'),(8,2,2026,'085000959070','2026-05-19',1143,'2026-08-21 04:52:05','2026-08-21 04:52:29'),(9,2,2026,'088001116387','2026-08-19',1143,'2026-08-21 04:53:42','2026-08-21 04:53:42'),(10,3,2025,'76129779','2025-11-01',3570,'2026-08-21 05:00:35','2026-08-21 05:00:35'),(11,1,2025,'6233552','2025-01-13',2142,'2026-08-21 05:05:07','2026-08-21 05:05:07'),(12,1,2025,'6425395','2025-09-28',985,'2026-08-28 13:26:16','2026-08-28 13:26:16'),(13,1,2025,'6433878','2025-10-05',17679,'2026-08-28 13:27:02','2026-08-28 13:27:02'),(14,1,2025,'6446295','2025-10-24',1071,'2026-08-28 13:27:30','2026-08-28 13:27:30'),(15,1,2025,'6490018','2025-12-24',1271,'2026-08-28 13:28:01','2026-08-28 13:28:01'),(16,4,2025,'69725658','2025-02-15',3451,'2026-08-29 11:55:58','2026-08-29 11:56:11'),(17,5,2025,'YOO/2025/01/925','2025-01-27',39151,'2026-08-29 11:57:58','2026-08-29 11:57:58'),(18,1,2025,'6241404','2025-01-24',1071,'2026-08-29 12:13:26','2026-08-29 12:13:26'),(19,1,2025,'6271823','2025-03-03',985,'2026-08-29 12:13:52','2026-08-29 12:13:52'),(20,1,2025,'6295813','2025-04-05',9282,'2026-08-29 12:14:17','2026-08-29 12:14:17'),(21,1,2025,'6308276','2025-04-24',1071,'2026-08-29 12:14:39','2026-08-29 12:14:39'),(22,1,2025,'6360519 (50%)','2025-07-06',2142,'2026-08-29 12:16:28','2026-08-29 12:16:28'),(23,1,2025,'6372335','2025-07-24',1071,'2026-08-29 12:17:46','2026-08-29 12:17:46'),(24,6,2025,'71968114de','2025-03-06',14900,'2026-08-29 12:29:23','2026-08-29 12:29:23'),(25,7,2026,'2026-000646','2026-08-01',367,'2026-09-02 05:36:38','2026-09-02 05:36:38'),(26,7,2026,'2026-000733','2026-09-01',714,'2026-09-02 05:37:22','2026-09-02 05:37:22');
/*!40000 ALTER TABLE `incoming_invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoices`
--

DROP TABLE IF EXISTS `invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoices` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `amount_cents` mediumint NOT NULL,
  `invoice_date` date NOT NULL,
  `customer_number` varchar(12) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `customer_last_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `filename` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `meta` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `source_quote_id` int unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoice_number` (`invoice_number`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoices`
--

LOCK TABLES `invoices` WRITE;
/*!40000 ALTER TABLE `invoices` DISABLE KEYS */;
INSERT INTO `invoices` VALUES (6,'202601014',6000,'2026-04-01','10015','vo.lan.di',2,'202601014volandi.pdf',NULL,NULL,'2026-07-06 10:23:29','2026-08-25 15:05:59'),(7,'202601015',8130,'2026-01-04','10006','Behnke',2,'202601015 mbb-24.pdf',NULL,NULL,'2026-07-06 10:23:29','2026-08-25 10:10:45'),(8,'202601017',20700,'2026-01-04','10001','Wiegmann',2,'202601017ihrtaxi-hamburg.pdf',NULL,NULL,'2026-07-06 10:23:29','2026-08-25 10:10:44'),(9,'202603018',5970,'2026-03-31','10006','Behnke',2,'202603018 mbb-24.pdf',NULL,NULL,'2026-07-06 10:23:29','2026-08-25 10:10:45'),(10,'202601016',9435,'2026-01-04','10014','Dreger',2,'202601016 silberring.pdf',NULL,NULL,'2026-07-06 10:23:29','2026-08-25 10:10:45'),(11,'202601019',9435,'2026-03-31','10014','siberring',2,'202601019silbering.pdf',NULL,NULL,'2026-07-06 10:23:29','2026-08-24 09:30:23'),(12,'202607020',34890,'2026-07-04','10006','Behnke',2,'202607020 mbb-24.pdf',NULL,NULL,'2026-07-06 10:23:29','2026-08-25 10:10:45'),(13,'202607021',9435,'2026-07-04','10014','Dreger',2,'202607021 silberring.pdf',NULL,NULL,'2026-07-06 10:23:29','2026-08-25 10:10:45'),(14,'2019060002',10680,'2019-06-28','10001','Wiegmann',2,'2019060002ihrtaxi-hamburg.pdf',NULL,NULL,'2026-08-25 10:10:44','2026-08-25 10:10:44'),(15,'2020010002',11760,'2020-01-05','10001','Wiegmann',2,'2020010002ihrtaxi-hamburg.pdf',NULL,NULL,'2026-08-25 10:10:44','2026-08-25 10:10:44'),(16,'2020060002',9600,'2020-06-29','10001','Wiegmann',2,'2020060002ihrtaxi-hamburg.pdf',NULL,NULL,'2026-08-25 10:10:44','2026-08-25 10:10:44'),(17,'2021010001',8100,'2021-01-02','10001','Wiegmann',2,'2021010001ihrtaxi-hamburg.pdf',NULL,NULL,'2026-08-25 10:10:44','2026-08-25 10:10:44'),(18,'2022010001',8100,'2022-01-06','10001','Wiegmann',2,'2022010001ihrtaxi-hamburg.pdf',NULL,NULL,'2026-08-25 10:10:44','2026-08-25 10:10:44'),(19,'2023010001',8700,'2023-01-02','10001','Wiegmann',2,'2023010001 Ihrtaxi-hamburg.pdf',NULL,NULL,'2026-08-25 10:10:44','2026-08-25 10:10:44'),(20,'2023090001',8000,'2023-09-18','10001','Wiegmann',2,'2023090001 ihrtaxi-hamburg.pdf',NULL,NULL,'2026-08-25 10:10:44','2026-08-25 10:10:44'),(21,'2024010001',8700,'2024-01-14','10001','Wiegmann',2,'2024010001ihrtaxi-hamburg.pdf',NULL,NULL,'2026-08-25 10:10:44','2026-08-25 10:10:44'),(22,'2024120001',16000,'2024-12-21','10001','Wiegmann',2,'2024120001 ihrtaxi-hamburg.pdf',NULL,NULL,'2026-08-25 10:10:44','2026-08-25 10:10:44'),(23,'2025010003',8700,'2025-01-02','10001','Wiegmann',2,'2025010003 ihrtaxi-hamburg.pdf',NULL,NULL,'2026-08-25 10:10:44','2026-08-25 10:10:44'),(24,'202504008',6000,'2025-04-06','10001','Wiegmann',2,'202504008 ihrtaxi-hamburg.pdf',NULL,NULL,'2026-08-25 10:10:44','2026-08-25 10:10:44'),(25,'202507010',6000,'2025-07-01','10001','Wiegmann',2,'202507010ihrtaxi-hamburg.pdf',NULL,NULL,'2026-08-25 10:10:44','2026-08-25 10:10:44'),(26,'2018070001',18125,'2018-07-10','10006','Behnke',2,'2018070001 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:44','2026-08-25 10:10:44'),(27,'2018110002',47125,'2018-11-20','10006','Behnke',2,'2018110002 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:44','2026-08-25 10:10:44'),(28,'2018120001',45600,'2018-12-17','10006','Behnke',2,'2018120001 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:44','2026-08-25 10:10:44'),(29,'2018120002',7250,'2018-12-28','10006','Behnke',2,'2018120002 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:44','2026-08-25 10:10:44'),(30,'2019010002',7920,'2019-01-02','10006','Behnke',2,'2019010002 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:44','2026-08-25 10:10:44'),(31,'2019030001',5760,'2019-03-27','10006','Behnke',2,'2019030001 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(32,'2019070001',5760,'2019-07-01','10006','Behnke',2,'2019070001 mbb24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(33,'2019090003',7260,'2019-09-26','10006','Behnke',2,'2019090003 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(34,'2020010001',9420,'2020-01-05','10006','Behnke',2,'2020010001 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(35,'2020030001',7260,'2020-03-30','10006','Behnke',2,'2020030001 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(36,'2020060001',7260,'2020-06-29','10006','Behnke',2,'2020060001 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(37,'2020100001',7260,'2020-10-04','10006','Behnke',2,'2020100001 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(38,'2021010002',9420,'2021-01-02','10006','Behnke',2,'2021010002 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(39,'2021050001',7260,'2021-05-02','10006','Behnke',2,'2021050001 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(40,'2021070001',7260,'2021-07-14','10006','Behnke',2,'2021070001 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(41,'2021090002',5760,'2021-09-30','10006','Behnke',2,'2021090002 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(42,'2022010002',7920,'2022-01-06','10006','Behnke',2,'2022010002 - mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(43,'2022040001',5760,'2022-03-31','10006','Behnke',2,'2022040001-mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(44,'2022070001',5970,'2022-07-05','10006','Behnke',2,'2022070001-mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(45,'2022100002',5970,'2022-10-02','10006','Behnke',2,'2022100002 -mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(46,'2023010002',8130,'2023-01-02','10006','Behnke',2,'2023010002 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(47,'2023040001',5970,'2023-04-04','10006','Behnke',2,'2023040001 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(48,'2023080001',5970,'2023-08-10','10006','Behnke',2,'2023080001 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(49,'2023100002',5970,'2023-10-04','10006','Behnke',2,'2023100002 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(50,'2024010002',8130,'2024-01-14','10006','Behnke',2,'2024010002 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(51,'2024040001',5970,'2024-04-03','10006','Behnke',2,'2024040001 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(52,'2024060001',5970,'2024-06-29','10006','Behnke',2,'2024060001 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(53,'2024090001',5970,'2024-09-30','10006','Behnke',2,'2024090001 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(54,'2025010004',8130,'2025-01-02','10006','Behnke',2,'2025010004 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(55,'202504007',5970,'2025-04-06','10006','Behnke',2,'202504007 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(56,'202507011',5970,'2025-07-01','10006','Behnke',2,'202507011mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(57,'202510013',5970,'2025-10-03','10006','Behnke',2,'202510013 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(58,'2024120002',19850,'2024-12-23','10014','Dreger',2,'2024120002 silberring.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(59,'2024120003',22531,'2024-12-28','10014','Dreger',2,'2024120003 silberring.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(60,'2025010005',35029,'2025-01-06','10014','Dreger',2,'2025010005 silberring.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(61,'202504006',9435,'2025-04-06','10014','Dreger',2,'202504006 silberring.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(62,'202507009',9435,'2025-07-01','10014','Dreger',2,'202507009 silberring.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(63,'202510012',9435,'2025-10-03','10014','Dreger',2,'202510012-silberring.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(64,'202603019',9435,'2026-03-31','10014','Dreger',2,'202603019 silberring.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(65,'2025010002',6000,'2025-01-02','10015','Lange',2,'2025010002 Volandi.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(66,'202608022',-6000,'2026-08-25','10015','Lange',9,'202608022volandi.pdf','{\"positions\":[{\"type\":\"custom\",\"title\":\"Updates, Wartung, Programmpflege, kleine Anpassungswünsche (Januar bis Dezember 2026)\",\"qty\":12,\"price_cents\":-500,\"unit\":\"Stck.\",\"position_number\":\"001\",\"position_source\":\"invoice_extra\"}],\"texts\":{\"intro_header\":\"Sehr geehrter Herr Lange,\",\"intro_items\":\"Entfallene Rechnungsartikel:\",\"footer\":\"In dieser Rechnung ist gemäß der Kleinunternehmer-Regelung (§19 Abs. 1 UStG) keine Umsatzsteuer enthalten und ausgewiesen.\"},\"correction_of\":\"202601014\",\"email_sent\":true}',NULL,'2026-08-25 15:10:37','2026-08-25 15:10:37');
/*!40000 ALTER TABLE `invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `class` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `group` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `namespace` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `time` int NOT NULL,
  `batch` int unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2026-07-06-100000','App\\Database\\Migrations\\CreateWumAccountingTables','default','App',1784206422,1),(2,'2026-07-07-100000','App\\Database\\Migrations\\AddDocumentPositions','default','App',1784206422,1),(3,'2026-07-14-100000','App\\Database\\Migrations\\ExpandMetaColumn','default','App',1784206422,1),(4,'2026-07-16-100000','App\\Database\\Migrations\\MigrateLegacyRightsAndDemoUser','default','App',1784206422,1),(5,'2026-07-31-100000','App\\Database\\Migrations\\CreateReceiptsTable','default','App',1785495653,2),(6,'2026-08-12-100000','App\\Database\\Migrations\\AddCustomerInvoiceFolder','default','App',1786632958,3),(7,'2026-08-13-100000','App\\Database\\Migrations\\CreateCreditorsAndIncomingInvoices','default','App',1786632958,3),(8,'2026-08-13-140000','App\\Database\\Migrations\\AddCreditorNumber','default','App',1786632958,3),(9,'2026-08-13-160000','App\\Database\\Migrations\\CreditorNumberAsText','default','App',1786632958,3);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quote_confirmations`
--

DROP TABLE IF EXISTS `quote_confirmations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quote_confirmations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `quote_id` int unsigned NOT NULL,
  `token` varchar(64) NOT NULL,
  `notes` text,
  `confirmation_date` date DEFAULT NULL,
  `signature_data` mediumtext,
  `email_copy` tinyint(1) NOT NULL DEFAULT '0',
  `privacy_consented_at` datetime DEFAULT NULL,
  `pdf_filename` varchar(100) DEFAULT NULL,
  `submitted_at` datetime DEFAULT NULL,
  `declined_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `quote_id` (`quote_id`),
  UNIQUE KEY `token` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quote_confirmations`
--

LOCK TABLES `quote_confirmations` WRITE;
/*!40000 ALTER TABLE `quote_confirmations` DISABLE KEYS */;
/*!40000 ALTER TABLE `quote_confirmations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quotes`
--

DROP TABLE IF EXISTS `quotes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quotes` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `quote_number` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `amount_cents` mediumint NOT NULL,
  `quote_date` date NOT NULL,
  `customer_number` varchar(12) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `company_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `filename` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `meta` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `invoice_id` int unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `quote_number` (`quote_number`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quotes`
--

LOCK TABLES `quotes` WRITE;
/*!40000 ALTER TABLE `quotes` DISABLE KEYS */;
INSERT INTO `quotes` VALUES (3,'202601',20600,'2026-07-14','10016','TEST',3,'Angebot202601.pdf','{\"positions\":[{\"type\":\"custom\",\"title\":\"Upgrade Joomla! von  der aktuellen 5er auf die aktuelle 6er Version (einschl. Testlauf)\",\"qty\":1,\"price_cents\":20000,\"unit\":\"psch.\",\"position_number\":\"001\",\"position_source\":\"quote\"},{\"type\":\"custom\",\"title\":\"ab 2026 Pro: BackupMonkey (monatlich - hier zusätzliche Kosten je Quartal)\",\"qty\":3,\"price_cents\":200,\"unit\":\"Stck.\",\"position_number\":\"002\",\"position_source\":\"quote\"},{\"type\":\"custom\",\"title\":\"Alternativ: test\",\"qty\":5,\"price_cents\":600,\"unit\":\"Stck.\",\"position_number\":\"003\",\"position_source\":\"quote\"},{\"type\":\"custom\",\"title\":\"Eventual: e - Test\",\"qty\":0,\"price_cents\":30000,\"unit\":\"Stck.\",\"position_number\":\"004\",\"position_source\":\"quote\"}],\"texts\":{\"intro_header\":\"Sehr geehrte Damen und Herren,\\r\\nwir erlauben uns, wie folgt in Rechnung zu stellen:\",\"intro_items\":\"Angebotene Leistungen:\",\"footer\":\"Hinweis:\"}}',NULL,'2026-07-14 12:40:33','2026-07-14 12:59:35'),(4,'202602',500,'2026-07-14','10016','TEST',3,'Angebot202602.pdf','{\"positions\":[{\"type\":\"custom\",\"title\":\"Test\",\"qty\":1,\"price_cents\":500,\"unit\":\"Stck.\",\"position_number\":\"001\",\"position_source\":\"quote\"}],\"texts\":{\"intro_header\":\"Hello World\",\"intro_items\":\"Angebotene Leistungen: Test\",\"footer\":\"\"},\"email_sent\":true}',NULL,'2026-07-14 12:59:23','2026-07-16 13:11:30');
/*!40000 ALTER TABLE `quotes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `receipts`
--

DROP TABLE IF EXISTS `receipts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `receipts` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `receipt_number` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `from_text` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `via_text` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `via2_text` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `to_text` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `time_text` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `waiting_time` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `agent` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `persons` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `price` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `receipt_date` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `vessel` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `signature_data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `receipt_number` (`receipt_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `receipts`
--

LOCK TABLES `receipts` WRITE;
/*!40000 ALTER TABLE `receipts` DISABLE KEYS */;
/*!40000 ALTER TABLE `receipts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schema_patches`
--

DROP TABLE IF EXISTS `schema_patches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schema_patches` (
  `id` varchar(64) NOT NULL,
  `applied_at` datetime NOT NULL,
  `message` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schema_patches`
--

LOCK TABLES `schema_patches` WRITE;
/*!40000 ALTER TABLE `schema_patches` DISABLE KEYS */;
INSERT INTO `schema_patches` VALUES ('sync_invoices_from_pdfs','2026-08-25 05:59:14','0 importiert, 0 aktualisiert, 64 übersprungen, 3 weitere auf bezahlt gesetzt. Hinweise: 2019060002ihrtaxi-hamburg.pdf: Nummer, Datum oder Betrag nicht lesbar. 2020010002ihrtaxi-hamburg.pdf: Nummer, Datum oder Betrag nicht lesbar. 2020060002ihrtaxi-hamburg.pdf: Nummer, Datum oder Betrag nicht lesbar. 2021010001ihrtaxi-hamburg.pdf: Nummer, Datum oder Betrag nicht lesbar. 2022010001ihrtaxi-hamburg.pdf: Nummer, Datum oder Betrag nicht lesbar. …'),('sync_invoices_from_pdfs_v4','2026-08-25 10:10:45','52 importiert, 7 aktualisiert, 0 übersprungen, 0 weitere auf bezahlt gesetzt.');
/*!40000 ALTER TABLE `schema_patches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `text_blocks`
--

DROP TABLE IF EXISTS `text_blocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `text_blocks` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `text_key` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `note` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `meta` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `text_key` (`text_key`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `text_blocks`
--

LOCK TABLES `text_blocks` WRITE;
/*!40000 ALTER TABLE `text_blocks` DISABLE KEYS */;
INSERT INTO `text_blocks` VALUES (1,'vor1','Sehr geehrte Damen und Herren,\r\nwir erlauben uns, wie folgt in Rechnung zu stellen:',1,'Anrede',NULL,'2026-07-06 10:23:15','2026-07-06 10:23:15'),(2,'schluss1','Sofern nicht anders angegeben, entspricht das Liefer-/Leistungsdatum dem Rechnungsdatum. \r\nZahlungsbedingungen: innerhalb von 14 Werktagen netto Kasse\r\nIn dieser Rechnung ist gemäß der Kleinunternehmer-Regelung (§19 Abs. 1 UStG) keine Umsatzsteuer enthalten und ausgewiesen.',1,'Standard',NULL,'2026-07-06 10:23:15','2026-07-06 11:30:49'),(5,'hin1','Hinweis:',1,'Text erscheint direkt vor den Rechnungsartikeln in der Tabelle ()',NULL,'2026-07-06 10:23:15','2026-07-06 10:23:15'),(6,'hin-silber','Wartungsvertrag Nr. 02/25 Automatische vierteljährliche Verlängerung, Kündigung: 1 Monat zum Laufzeitende. \r\n\r\nHier: 3. Quartal 01.10.2026 bis 31.12.2026',1,'silberring-Wartungsvertrag',NULL,'2026-07-06 10:23:15','2026-07-06 11:40:18'),(7,'hin-taxi','Projekt-Domain: https://rechnung.ihr-taxi-hamburg.de Individuelle Buchhaltung mit Kassenbuch,\r\nRechnung und Wallet. Auswertungen für den Steuerberater',1,'ihrtaxi-Projekt',NULL,'2026-07-06 10:23:15','2026-07-06 11:40:43'),(8,'hin-mbb-24','Wartungsvertrag Nr. 01/18 (Vertragslaufzeit 1 Jahr). \r\nAutomatische jährliche Verlängerung!\r\nKündigung 1 Monat zum Quartalsende.\r\n\r\nHier: 4. Quartale: 01.01.2027 bis 31.12.2027',1,'mbb24 - Wartungsvertrag',NULL,'2026-07-06 10:23:15','2026-07-06 11:42:51');
/*!40000 ALTER TABLE `text_blocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` tinyint(1) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `first_name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `last_name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `rights` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT 'tz67',
  `selection` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL COMMENT 'not used',
  PRIMARY KEY (`id`),
  UNIQUE KEY `userername` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'wumy','$2y$10$qHgW2bcQDG/k/0t30JWe.OvlcT8NkTA3kMiZbRkTCEc7ZC/aoGBD6','Marko','Jorissen','2026-07-16 12:38:14','2023-05-07 09:27:40','superadmin','2025'),(2,'demo','$2y$10$9K2xGA8ByQU7.qceRYgsNu4Sr56NlC/JZpLX9SbZysMQMXPWIiOuq','Max','Tester','2026-07-28 13:15:06','2026-07-16 11:52:03','demo',NULL),(3,'hansen','$2y$10$HkaIIPJA3zCQTmc0NX2iC.BxWJMReEOQSb1d.qR9U/kU7c06lVGxa','Hermann','Hansen','2026-07-31 07:54:53','2026-07-31 07:54:53','demo',NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-03  9:10:24
