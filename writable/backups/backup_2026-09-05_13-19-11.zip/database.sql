-- MySQL dump 10.13  Distrib 5.7.44, for Linux (x86_64)
--
-- Host: db002767.mydbserver.com    Database: usr_p482496_5
-- ------------------------------------------------------
-- Server version	8.4.8-8

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `articles`
--

DROP TABLE IF EXISTS `articles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `articles` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `article_number` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `price_cents` mediumint NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `note` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `meta` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `article_number` (`article_number`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `articles`
--

LOCK TABLES `articles` WRITE;
/*!40000 ALTER TABLE `articles` DISABLE KEYS */;
INSERT INTO `articles` VALUES (1,'mbb24-hosting','Anteilige Hostinggebühr, alle erforderlichen monatlichen Arbeiten, im Zusammenhang mit der Webseite! Jedoch ohne größere Änderungen, diese müssen separat berechnet werden.',8845,1,'vierteljährlich',NULL,'2026-07-06 10:23:15','2026-07-06 10:23:15'),(2,'mbb24-domain','Jährliche Domainkosten für mbb-24.de',240,1,NULL,NULL,'2026-07-06 10:23:15','2026-07-06 10:23:15'),(3,'mbb24-sicherheit','Sicherheitspaket gemäß E-Mail:Upgrade CMS - System (Joomla6): 95€Impressum & Datenschutz: 77€',17200,0,'einmalig 2026',NULL,'2026-07-06 10:23:15','2026-07-06 17:00:09'),(4,'mbb24-sicherheit-jährlich','Aktualisierung von Impressum &amp; Datenschutz, wenn erforderlich\r\nGrundlage: Mein Abo bei Erecht24 als Basis\r\nKeine Rechtsberatung',1900,1,'NEU',NULL,'2026-07-06 10:23:15','2026-07-06 10:23:15'),(5,'silber-datensicherung','Monatliche Datensicherung mit Akeeba Backup\r\nPro, einschl. automatisierter Speicherung auf\r\nexterner deutscher Qloud (Hetzner)',995,1,'monatlich',NULL,'2026-07-06 10:23:15','2026-07-06 10:23:15'),(6,'silber-wartung','Joomla! Aktualisierungen nach Erfordernis,\r\nAktualisierungen von meinen Erweiterungen,\r\nwelche bei mir enthalten sind, JCE - Editor (ggf. Pro),\r\nAkeeba Backup (Pro),Template / Builder: Yootheme Pro\r\nBackupMonkey bis 31.12.2026 kostenlos',2150,1,'monatlich, ab 2027 +2€ für BM',NULL,'2026-07-06 10:23:15','2026-07-06 10:23:15'),(7,'ihrtaxi-domain','Jährliche Domainkosten für Endung .de (IhrTaxi-Hamburg.de)',2400,1,'(alt: 1,80/Monat)',NULL,'2026-07-06 10:23:15','2026-07-06 10:23:15'),(8,'ihrtaxi-email-postfach','Emailpostfach 3 Gigabyte, mit SPAM-Schutz und\r\nunendlich vielen Email- Adressen',6975,1,'jährlich (vorher 65,40)',NULL,'2026-07-06 10:23:15','2026-07-06 10:23:15'),(9,'ihrtaxi-programm','Updates und Pflege der Webseite, einschließlich\r\nDatensicherung (ohne Gewähr, Datensicherung ist per Hand)\r\nSpeicherung auf der Webseite &amp; bei Hetzner in externer deutscher Cloud',120,1,'jährlich (Preis bleibt konstant)',NULL,'2026-07-06 10:23:15','2026-07-06 10:23:15');
/*!40000 ALTER TABLE `articles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `creditors`
--

DROP TABLE IF EXISTS `creditors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `creditors` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `creditor_number` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `company_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `note` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `meta` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `creditor_number` (`creditor_number`),
  UNIQUE KEY `company_name_unique` (`company_name`),
  KEY `company_name` (`company_name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `creditors`
--

LOCK TABLES `creditors` WRITE;
/*!40000 ALTER TABLE `creditors` DISABLE KEYS */;
INSERT INTO `creditors` VALUES (1,'388252','Mittwald',1,'Hoster',NULL,'2026-08-13 15:12:23','2026-08-24 08:19:25'),(2,'K0970955323','Hetzner Online GmbH',1,'Qloud-Speicher',NULL,'2026-08-20 16:34:09','2026-08-24 08:19:02'),(3,'8172165','Akeeba Ltd',1,'Datensicherung',NULL,'2026-08-21 05:00:35','2026-08-24 08:19:15'),(4,'08172165','Paddle (JCE)',1,NULL,NULL,'2026-08-29 11:55:58','2026-08-29 11:55:58'),(5,'DE260820446','Yootheme',1,NULL,NULL,'2026-08-29 11:57:58','2026-08-29 11:57:58'),(6,'B5450459','Digistore24 (eRecht24)',1,NULL,NULL,'2026-08-29 12:29:23','2026-08-29 12:29:23'),(7,'DE323248038','BackupMonkey UG',1,NULL,NULL,'2026-09-02 05:36:38','2026-09-02 05:36:38');
/*!40000 ALTER TABLE `creditors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `customer_number` bigint DEFAULT NULL,
  `company` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `first_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `last_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `street` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `postal_code` int NOT NULL,
  `city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'Hamburg',
  `phone` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `invoice_folder` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `note` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `meta` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_number` (`customer_number`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,10001,'Taxenbetrieb Frank Wiegmann','Frank','Wiegmann','Ellerneck 8e',22045,'Hamburg','','info@ihrtaxi-hamburg.de',NULL,'',1,NULL,'2026-07-06 10:23:15','2026-07-06 10:23:15'),(2,10015,'vo.lan.di','Volker','Lange','Lübecker Straße 10',39576,'Stendal','','volandi@freepasswort.de','volandi','Altes Notebook OFFLINE',1,NULL,'2026-07-06 10:23:15','2026-08-25 15:10:37'),(3,10006,'Malereibetrieb Björn Behnke GmbH','Björn','Behnke','Eulenkamp 2',22049,'Hamburg','','rechnung@mbb-24.de',NULL,'',1,NULL,'2026-07-06 10:23:15','2026-07-06 10:23:15'),(4,10014,'Reinhard Dreger e.K.','Reinhard','Dreger','Römeberg 9',21400,'Reinstorf OT Wendhausen','','info@silberring.info',NULL,'',1,NULL,'2026-07-06 10:23:15','2026-07-06 10:23:15');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `incoming_invoices`
--

DROP TABLE IF EXISTS `incoming_invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `incoming_invoices` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `creditor_id` int unsigned NOT NULL,
  `booking_year` smallint unsigned NOT NULL,
  `invoice_number` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `invoice_date` date NOT NULL,
  `amount_cents` int NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `creditor_id_invoice_number_booking_year` (`creditor_id`,`invoice_number`,`booking_year`),
  KEY `creditor_id` (`creditor_id`),
  KEY `booking_year` (`booking_year`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `incoming_invoices`
--

LOCK TABLES `incoming_invoices` WRITE;
/*!40000 ALTER TABLE `incoming_invoices` DISABLE KEYS */;
INSERT INTO `incoming_invoices` VALUES (1,2,2025,'086000156249','2025-02-19',762,'2026-08-20 16:34:09','2026-08-20 16:34:09'),(2,2,2025,'082000256707','2025-04-19',762,'2026-08-20 16:35:23','2026-08-20 16:35:23'),(3,2,2025,'08900040253','2025-06-19',762,'2026-08-20 16:36:06','2026-08-20 16:36:06'),(4,2,2025,'084000410769','2025-08-19',762,'2026-08-20 16:36:48','2026-08-20 16:36:48'),(5,2,2025,'085000573218','2025-10-19',762,'2026-08-20 16:37:29','2026-08-20 16:37:29'),(6,2,2025,'085000670931','2025-12-19',762,'2026-08-20 16:38:09','2026-08-20 16:38:09'),(7,2,2026,'080000740041','2026-02-19',762,'2026-08-21 04:50:47','2026-08-21 04:50:47'),(8,2,2026,'085000959070','2026-05-19',1143,'2026-08-21 04:52:05','2026-08-21 04:52:29'),(9,2,2026,'088001116387','2026-08-19',1143,'2026-08-21 04:53:42','2026-08-21 04:53:42'),(10,3,2025,'76129779','2025-11-01',3570,'2026-08-21 05:00:35','2026-08-21 05:00:35'),(11,1,2025,'6233552','2025-01-13',2142,'2026-08-21 05:05:07','2026-08-21 05:05:07'),(12,1,2025,'6425395','2025-09-28',985,'2026-08-28 13:26:16','2026-08-28 13:26:16'),(13,1,2025,'6433878','2025-10-05',17679,'2026-08-28 13:27:02','2026-08-28 13:27:02'),(14,1,2025,'6446295','2025-10-24',1071,'2026-08-28 13:27:30','2026-08-28 13:27:30'),(15,1,2025,'6490018','2025-12-24',1271,'2026-08-28 13:28:01','2026-08-28 13:28:01'),(16,4,2025,'69725658','2025-02-15',3451,'2026-08-29 11:55:58','2026-08-29 11:56:11'),(17,5,2025,'YOO/2025/01/925','2025-01-27',39151,'2026-08-29 11:57:58','2026-08-29 11:57:58'),(18,1,2025,'6241404','2025-01-24',1071,'2026-08-29 12:13:26','2026-08-29 12:13:26'),(19,1,2025,'6271823','2025-03-03',985,'2026-08-29 12:13:52','2026-08-29 12:13:52'),(20,1,2025,'6295813','2025-04-05',9282,'2026-08-29 12:14:17','2026-08-29 12:14:17'),(21,1,2025,'6308276','2025-04-24',1071,'2026-08-29 12:14:39','2026-08-29 12:14:39'),(22,1,2025,'6360519 (50%)','2025-07-06',2142,'2026-08-29 12:16:28','2026-08-29 12:16:28'),(23,1,2025,'6372335','2025-07-24',1071,'2026-08-29 12:17:46','2026-08-29 12:17:46'),(24,6,2025,'71968114de','2025-03-06',14900,'2026-08-29 12:29:23','2026-08-29 12:29:23'),(25,7,2026,'2026-000646','2026-08-01',367,'2026-09-02 05:36:38','2026-09-02 05:36:38'),(26,7,2026,'2026-000733','2026-09-01',714,'2026-09-02 05:37:22','2026-09-02 05:37:22');
/*!40000 ALTER TABLE `incoming_invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoices`
--

DROP TABLE IF EXISTS `invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoices` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `amount_cents` mediumint NOT NULL,
  `invoice_date` date NOT NULL,
  `customer_number` varchar(12) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `customer_last_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `filename` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `meta` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `source_quote_id` int unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoice_number` (`invoice_number`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoices`
--

LOCK TABLES `invoices` WRITE;
/*!40000 ALTER TABLE `invoices` DISABLE KEYS */;
INSERT INTO `invoices` VALUES (6,'202601014',6000,'2026-04-01','10015','vo.lan.di',2,'202601014volandi.pdf',NULL,NULL,'2026-07-06 10:23:29','2026-08-25 15:05:59'),(7,'202601015',8130,'2026-01-04','10006','Behnke',2,'202601015 mbb-24.pdf',NULL,NULL,'2026-07-06 10:23:29','2026-08-25 10:10:45'),(8,'202601017',20700,'2026-01-04','10001','Wiegmann',2,'202601017ihrtaxi-hamburg.pdf',NULL,NULL,'2026-07-06 10:23:29','2026-08-25 10:10:44'),(9,'202603018',5970,'2026-03-31','10006','Behnke',2,'202603018 mbb-24.pdf',NULL,NULL,'2026-07-06 10:23:29','2026-08-25 10:10:45'),(10,'202601016',9435,'2026-01-04','10014','Dreger',2,'202601016 silberring.pdf',NULL,NULL,'2026-07-06 10:23:29','2026-08-25 10:10:45'),(11,'202601019',9435,'2026-03-31','10014','siberring',2,'202601019silbering.pdf',NULL,NULL,'2026-07-06 10:23:29','2026-08-24 09:30:23'),(12,'202607020',34890,'2026-07-04','10006','Behnke',2,'202607020 mbb-24.pdf',NULL,NULL,'2026-07-06 10:23:29','2026-08-25 10:10:45'),(13,'202607021',9435,'2026-07-04','10014','Dreger',2,'202607021 silberring.pdf',NULL,NULL,'2026-07-06 10:23:29','2026-08-25 10:10:45'),(14,'2019060002',10680,'2019-06-28','10001','Wiegmann',2,'2019060002ihrtaxi-hamburg.pdf',NULL,NULL,'2026-08-25 10:10:44','2026-08-25 10:10:44'),(15,'2020010002',11760,'2020-01-05','10001','Wiegmann',2,'2020010002ihrtaxi-hamburg.pdf',NULL,NULL,'2026-08-25 10:10:44','2026-08-25 10:10:44'),(16,'2020060002',9600,'2020-06-29','10001','Wiegmann',2,'2020060002ihrtaxi-hamburg.pdf',NULL,NULL,'2026-08-25 10:10:44','2026-08-25 10:10:44'),(17,'2021010001',8100,'2021-01-02','10001','Wiegmann',2,'2021010001ihrtaxi-hamburg.pdf',NULL,NULL,'2026-08-25 10:10:44','2026-08-25 10:10:44'),(18,'2022010001',8100,'2022-01-06','10001','Wiegmann',2,'2022010001ihrtaxi-hamburg.pdf',NULL,NULL,'2026-08-25 10:10:44','2026-08-25 10:10:44'),(19,'2023010001',8700,'2023-01-02','10001','Wiegmann',2,'2023010001 Ihrtaxi-hamburg.pdf',NULL,NULL,'2026-08-25 10:10:44','2026-08-25 10:10:44'),(20,'2023090001',8000,'2023-09-18','10001','Wiegmann',2,'2023090001 ihrtaxi-hamburg.pdf',NULL,NULL,'2026-08-25 10:10:44','2026-08-25 10:10:44'),(21,'2024010001',8700,'2024-01-14','10001','Wiegmann',2,'2024010001ihrtaxi-hamburg.pdf',NULL,NULL,'2026-08-25 10:10:44','2026-08-25 10:10:44'),(22,'2024120001',16000,'2024-12-21','10001','Wiegmann',2,'2024120001 ihrtaxi-hamburg.pdf',NULL,NULL,'2026-08-25 10:10:44','2026-08-25 10:10:44'),(23,'2025010003',8700,'2025-01-02','10001','Wiegmann',2,'2025010003 ihrtaxi-hamburg.pdf',NULL,NULL,'2026-08-25 10:10:44','2026-08-25 10:10:44'),(24,'202504008',6000,'2025-04-06','10001','Wiegmann',2,'202504008 ihrtaxi-hamburg.pdf',NULL,NULL,'2026-08-25 10:10:44','2026-08-25 10:10:44'),(25,'202507010',6000,'2025-07-01','10001','Wiegmann',2,'202507010ihrtaxi-hamburg.pdf',NULL,NULL,'2026-08-25 10:10:44','2026-08-25 10:10:44'),(26,'2018070001',18125,'2018-07-10','10006','Behnke',2,'2018070001 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:44','2026-08-25 10:10:44'),(27,'2018110002',47125,'2018-11-20','10006','Behnke',2,'2018110002 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:44','2026-08-25 10:10:44'),(28,'2018120001',45600,'2018-12-17','10006','Behnke',2,'2018120001 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:44','2026-08-25 10:10:44'),(29,'2018120002',7250,'2018-12-28','10006','Behnke',2,'2018120002 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:44','2026-08-25 10:10:44'),(30,'2019010002',7920,'2019-01-02','10006','Behnke',2,'2019010002 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:44','2026-08-25 10:10:44'),(31,'2019030001',5760,'2019-03-27','10006','Behnke',2,'2019030001 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(32,'2019070001',5760,'2019-07-01','10006','Behnke',2,'2019070001 mbb24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(33,'2019090003',7260,'2019-09-26','10006','Behnke',2,'2019090003 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(34,'2020010001',9420,'2020-01-05','10006','Behnke',2,'2020010001 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(35,'2020030001',7260,'2020-03-30','10006','Behnke',2,'2020030001 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(36,'2020060001',7260,'2020-06-29','10006','Behnke',2,'2020060001 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(37,'2020100001',7260,'2020-10-04','10006','Behnke',2,'2020100001 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(38,'2021010002',9420,'2021-01-02','10006','Behnke',2,'2021010002 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(39,'2021050001',7260,'2021-05-02','10006','Behnke',2,'2021050001 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(40,'2021070001',7260,'2021-07-14','10006','Behnke',2,'2021070001 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(41,'2021090002',5760,'2021-09-30','10006','Behnke',2,'2021090002 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(42,'2022010002',7920,'2022-01-06','10006','Behnke',2,'2022010002 - mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(43,'2022040001',5760,'2022-03-31','10006','Behnke',2,'2022040001-mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(44,'2022070001',5970,'2022-07-05','10006','Behnke',2,'2022070001-mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(45,'2022100002',5970,'2022-10-02','10006','Behnke',2,'2022100002 -mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(46,'2023010002',8130,'2023-01-02','10006','Behnke',2,'2023010002 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(47,'2023040001',5970,'2023-04-04','10006','Behnke',2,'2023040001 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(48,'2023080001',5970,'2023-08-10','10006','Behnke',2,'2023080001 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(49,'2023100002',5970,'2023-10-04','10006','Behnke',2,'2023100002 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(50,'2024010002',8130,'2024-01-14','10006','Behnke',2,'2024010002 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(51,'2024040001',5970,'2024-04-03','10006','Behnke',2,'2024040001 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(52,'2024060001',5970,'2024-06-29','10006','Behnke',2,'2024060001 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(53,'2024090001',5970,'2024-09-30','10006','Behnke',2,'2024090001 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(54,'2025010004',8130,'2025-01-02','10006','Behnke',2,'2025010004 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(55,'202504007',5970,'2025-04-06','10006','Behnke',2,'202504007 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(56,'202507011',5970,'2025-07-01','10006','Behnke',2,'202507011mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(57,'202510013',5970,'2025-10-03','10006','Behnke',2,'202510013 mbb-24.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(58,'2024120002',19850,'2024-12-23','10014','Dreger',2,'2024120002 silberring.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(59,'2024120003',22531,'2024-12-28','10014','Dreger',2,'2024120003 silberring.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(60,'2025010005',35029,'2025-01-06','10014','Dreger',2,'2025010005 silberring.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(61,'202504006',9435,'2025-04-06','10014','Dreger',2,'202504006 silberring.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(62,'202507009',9435,'2025-07-01','10014','Dreger',2,'202507009 silberring.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(63,'202510012',9435,'2025-10-03','10014','Dreger',2,'202510012-silberring.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(64,'202603019',9435,'2026-03-31','10014','Dreger',2,'202603019 silberring.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(65,'2025010002',6000,'2025-01-02','10015','Lange',2,'2025010002 Volandi.pdf',NULL,NULL,'2026-08-25 10:10:45','2026-08-25 10:10:45'),(66,'202608022',-6000,'2026-08-25','10015','Lange',9,'202608022volandi.pdf','{\"positions\":[{\"type\":\"custom\",\"title\":\"Updates, Wartung, Programmpflege, kleine Anpassungswünsche (Januar bis Dezember 2026)\",\"qty\":12,\"price_cents\":-500,\"unit\":\"Stck.\",\"position_number\":\"001\",\"position_source\":\"invoice_extra\"}],\"texts\":{\"intro_header\":\"Sehr geehrter Herr Lange,\",\"intro_items\":\"Entfallene Rechnungsartikel:\",\"footer\":\"In dieser Rechnung ist gemäß der Kleinunternehmer-Regelung (§19 Abs. 1 UStG) keine Umsatzsteuer enthalten und ausgewiesen.\"},\"correction_of\":\"202601014\",\"email_sent\":true}',NULL,'2026-08-25 15:10:37','2026-08-25 15:10:37');
/*!40000 ALTER TABLE `invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `class` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `group` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `namespace` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `time` int NOT NULL,
  `batch` int unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2026-07-06-100000','App\\Database\\Migrations\\CreateWumAccountingTables','default','App',1784206422,1),(2,'2026-07-07-100000','App\\Database\\Migrations\\AddDocumentPositions','default','App',1784206422,1),(3,'2026-07-14-100000','App\\Database\\Migrations\\ExpandMetaColumn','default','App',1784206422,1),(4,'2026-07-16-100000','App\\Database\\Migrations\\MigrateLegacyRightsAndDemoUser','default','App',1784206422,1),(5,'2026-07-31-100000','App\\Database\\Migrations\\CreateReceiptsTable','default','App',1785495653,2),(6,'2026-08-12-100000','App\\Database\\Migrations\\AddCustomerInvoiceFolder','default','App',1786632958,3),(7,'2026-08-13-100000','App\\Database\\Migrations\\CreateCreditorsAndIncomingInvoices','default','App',1786632958,3),(8,'2026-08-13-140000','App\\Database\\Migrations\\AddCreditorNumber','default','App',1786632958,3),(9,'2026-08-13-160000','App\\Database\\Migrations\\CreditorNumberAsText','default','App',1786632958,3);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quote_confirmations`
--

DROP TABLE IF EXISTS `quote_confirmations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quote_confirmations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `quote_id` int unsigned NOT NULL,
  `token` varchar(64) NOT NULL,
  `notes` text,
  `confirmation_date` date DEFAULT NULL,
  `signature_data` mediumtext,
  `email_copy` tinyint(1) NOT NULL DEFAULT '0',
  `privacy_consented_at` datetime DEFAULT NULL,
  `pdf_filename` varchar(100) DEFAULT NULL,
  `submitted_at` datetime DEFAULT NULL,
  `declined_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `quote_id` (`quote_id`),
  UNIQUE KEY `token` (`token`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quote_confirmations`
--

LOCK TABLES `quote_confirmations` WRITE;
/*!40000 ALTER TABLE `quote_confirmations` DISABLE KEYS */;
INSERT INTO `quote_confirmations` VALUES (1,5,'f051dc36d015cc6368835b1231070d6e7525e4b445a3995b4c81d48db68ea8d2','Ok','2026-09-04','data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAxIAAAFoCAYAAADD4s1FAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAADEqADAAQAAAABAAABaAAAAAAIEUT8AABAAElEQVR4Ae2dB5glVZmwJ3VPnmESGYkiLOqiGFFBAZU1i2nXyCKyKuZVUVcUxfgriqCrYlwxr6AYMBAWRRQMiAFFkaCOwDiBMNOTemb6f0/bt61bXVU331vhree53XXyd95Tdc75Tqpp07wkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJFA2AjvvvPP+O+2000VLly69ZMWKFQeULX/mRwISkIAEJNAugRntBjScBCQggSoQGB0dPWH69OnHjI2NHbV9+/aTqpBn8ygBCUhAAhJohoCKRDOU9CMBCVSZwBG1zO/YsePh3A/VzP6XgAQkIAEJVJmAikSVS9+8S0ACzRBYWvPEzMQ/cT+zZva/BCQgAQlIoMoEVCSqXPrmXQISaEgA5eGWiKfpS5YsmR0xeysBCUhAAhKoLAEVicoWvRmXgASaIcDeiKgiMYM9EyoSzYDTjwQkIAEJlJ6AikTpi9gMSkACHRKIKhLTh4eHVSQ6BGpwCUhAAhIoBwEViXKUo7mQgAR6RCA+I7Ft2zYViR6xNloJSEACEigWARWJYpWX0kpAAn0mMGPGjLoZiVmzZg33WQSTk4AEJCABCeSSgIpELotFoSQggRwRqFMkOALWGYkcFY6iSEACEpDA4AioSAyOvSlLQAIFIIDiEFUkZnCK0/wCiK2IEpCABCQggZ4TUJHoOWITkIAEikzgjjvuCIrEpok8oEdM36PI+VF2CUhAAhKQQLcIqEh0i6TxSEACZSUwSsY21jLHDMXOtXv/S0ACEpCABKpMQEWiyqVv3iUggWYJjNQ8svl6Re3e/xKQgAQkIIEqE1CRqHLpm3cJSKBZApMzEhwH64xEs9T0JwEJSEACpSagIlHq4jVzEpBAlwhMKhLskXBGoktQjUYCEpCABIpNQEWi2OWn9BKQQH8ITC5tYkZCRaI/zE1FAhKQgARyTkBFIucFpHgSkEAuCEwqEsxIuLQpF0WiEBKQgAQkMGgCKhKDLgHTl4AEck+AWYjJpU0TeyRm5l5oBZSABCQgAQn0mICKRI8BG70EJFAKArdGcrFk0aJFiyNmbyUgAQlIQAKVJKAiUcliN9MSkEArBDjydU3UP8ubVCSiQLyXgAQkIIFKElCRqGSxm2kJSKAVAigO66L+VSSiNLyXgAQkIIGqElCRqGrJm28JSKBpAnzNuk6RIKAzEk3T06MEJCABCZSVgIpEWUvWfElAAt0kcHssMhWJGBCNEpCABCRQPQIqEtUrc3MsAQm0SCC+tIngKhItMtS7BCQgAQmUj4CKRPnK1BxJQAJdJjA6Olq3tMk9El0GbHQSkIAEJFBIAioShSw2hZaABPpJgG9H1CkSmJf2M33TkoAEJCABCeSRgIpEHktFmSQggVwR2LBhQ1Ak7qwJxYzEbrV7/0tAAhKQgASqSkBFoqolb74lIIFWCGzH89pIgEWRe28lIAEJSEAClSSgIlHJYjfTEpBAqwSYhYgqEgtbDa9/CUhAAhKQQNkIqEiUrUTNjwQk0BMCsX0SKhI9oWykEpCABCRQJAIqEkUqLWWVgAQGSWByRoLZCRWJQZaEaUtAAhKQQC4IqEjkohgUQgISKACBSUUCWd0jUYACU0QJSEACEugtARWJ3vI1dglIoCQEXNpUkoI0GxKQgAQk0DUCKhJdQ2lEEpBAyQlMzkigVISlTbNKnl+zJwEJSEACEsgkoCKRiUdHCUhAApME/jp5N23a/KVLl+4aMXsrAQlIQAISqBwBFYnKFbkZloAE2iEwY8aM9dFw27dv3yVq9l4CEpCABCRQNQIqElUrcfMrAQm0RYDlTBujAVEsVCSiQLyXgAQkIIHKEVCRqFyRm2EJSKAdAjt27NgUDccRsC5tigLxXgISkIAEKkdARaJyRW6GJSCBdgjMmjWrbkaCGQpnJNoBaRgJSEACEigNARWJ0hSlGZGABHpJgD0R8RkJFYleAjduCUhAAhLIPQEVidwXkQJKQAJ5ILBt27a6GQlkUpHIQ8EogwQkIAEJDIyAisTA0JuwBCRQJAJz586tm5Fgz0TYIzG9SHlQVglIQAISkEA3CahIdJOmcUlAAqUlsHr16o3si/hbLYMTm61n1sz+l4AEJCABCVSNgIpE1Urc/EpAAu0S2IHycEsk8BD3KhIRIN5KQAISkEC1CKhIVKu8za0EJNAZgZWR4EO77767ikQEiLcSkIAEJFAtAioS1SpvcysBCXRGIDojMbx161YVic54GloCEpCABApMQEWiwIWn6BKQQH8JsEfir5EUhzjJSUUiAsRbCUhAAhKoFgEViWqVt7mVgAQ6IDBjxoy6pU18W0JFogOeBpWABCQggWITUJEodvkpvQQk0F8C0aVNQ/PmzVOR6C9/U5OABCQggRwRUJHIUWEoigQkkG8C8aVN7JGYk2+JlU4CEpCABCTQOwIqEr1ja8wSkEDJCKBI/IXf1olszeI42D1LlkWzIwEJSEACEmiagIpE06j0KAEJVJ0AS5m2ojzUFIlp7JHYrepMzL8EJCABCVSXgIpEdcvenEtAAi0SYLP1GEG21IJhVpGowfC/BCQgAQlUjoCKROWK3AxLQALtEli5cuUOwk4qEtzv3m5chpOABCQgAQkUnYCKRNFLUPklIIF+EqibkWCZkzMS/aRvWhKQgAQkkCsCKhK5Kg6FkYAEck6gTpFAVhWJnBeY4klAAhKQQO8IqEj0jq0xS0AC5SNQt7SJE5xc2lS+MjZHEpCABCTQJAEViSZB6U0CEpAABNAdxib3SHC/q1QkIAEJSEACVSWgIlHVkjffEpBAOwTG2BdxYyTgnZF7byUgAQlIQAKVIqAiUaniNrMSkECHBIIicWUtDo5/vbx2738JSEACEpBA1QjMrFqGza8EJCCBTgjMnDnzJhSI+6FQzOL/izZt2rSmk/gMKwEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQqTWB6pXNv5iVQcAJz5sz59uzZsx81ffr0Gfy6lpvbb7+9e5F1TSojkoAEJCABCUggTwTsLOSpNJRFAtkEli5atOj6GTNmLEFp6Om7O8Z1xx13zMgWR1cJSEACEpCABKpMoKedkSqDNe8S6JTAggULnjFz5swvBKWBq9PoWg6PLrEOZWJZywENIAEJSEACEpBAJQj0v3dSCaxmUgLtEWDG4YHMOPx4IJpDgsjI8ZB169b9KMFJKwlIQAISkIAEKk7ApQsVfwDMfi4ILFq4cOGanXbaaYwZiCvzokQEMsxKXMHMyGm5oKQQEpCABCQgAQnkioAzErkqjo6EmbF48eLNjGYPTcSykg2z+3E/2lGsBu4ZAWYfvkh5PT1PikNSZlEmprHEyboiCY52EpCABCQggQoTsHNQgsJHgVhPh3RBPCt0UA9hWcpv4/aaB0dg3rx57xgeHn5dL5QHOvxj27dv37F+/fpZ7eaQWZF1yLYkHp6of44ycb+4vWYJSEACEpCABKpLQEWioGU/NDT0oPnz5/8oq0OqIpGfwkXZ246y19WlhEFx2LRp03u3bNny2m7mdMmSJWNJ8c2aNWu31atX35bkpp0EJCABCUhAAtUj0PbIZfVQ5SPHrFdfQYfubygJ+RBIKbIIXMUI//2zlL2swFE3dIZpO3bs2L5t27a9Nm7ceGvUrdv3W7du/QyzJs+Nx0vat5Kf5zMz8cm4m2YJSEACEpCABKpHwN5oQcqc9fQfZED75FYUCGckBlO4bJzehrI3s5PUw2wD1xfuvPPOZ3UST7thmZUI6X42Hj4IhSLR1ZmVeBqaJSABCUhAAhIoBgEViZyXE53SX9IpvXcbYrrZug1o7QZB0XsZit6Zncw+0EcPsw47kGHFXXfdta5dWboVjtmHHUn5we489t48tVvpGI8EJCABCUhAAsUkoCKRz3Kbzpr68C2BB/JrScLQGeX6JKPGz28poJ7bIoACsZ0jWzsaoQ+j/Fz3Z/bh520J0aNAPIPhC9ph8/WUFEZHR+/asGHD4ikOWkhAAhKQgAQkUBkCU3sIlcl6/jLK/oeTmX04m45bW+XCGvYfc2LP4fnLWfkkShutbzanQXNgo/QP2Sh9RLNhBuUvbfM1WXgECutlg5LLdCUgAQlIQAISGCwBN1sPlv946oz83sWymIXtiEJnLnw07IWMZn+0nfCGGSfwRE7A+jJK3KyIEjeuzLWp06Vi5XjW7SxbKtR7x/N1KhxOT8jU/2HXltKbEJdWEpCABCQgAQkUjICdgAEVGLMPO9NvvS3ScW1JEjp3YxwBu4jjODe0FLCinufMmfMCTiL6MApbWIbULva26IWyKvoG5YwZmPfy4cPXtAXGQBKQgAQkIAEJFJqAikSfi4/Zhz/Ri70bv7ZSpk+6jU7pgQS+qa0IShxo9uzZJ/M7C11hHG5ftYUEruHjcMw+dHR6U0K0A7HiQ3r3QRG7Oum5JZ/Xks97DkQwE5WABCQgAQlIYGAE2uvNDkzcYibMaO5pSP6mTjq2HOZzB8uXpnxxuJhEui/10qVLL0HJOqr7MbcWY5h9oKxeRsf6g62FLIbvjP0S+6Lg3lyMXCilBCQgAQlIQALdIFCotdrdyHA/42D2YRuj422PSNMnDfsfrkaBuB9yJ35tuJ/5yXFaM+E0UCWCje7b2ehe+vcJzp9AIZ5yIhh2YYbMgYkBvCRR5Y7yuRmFbt8BiGGSEpCABCRQQQI2/F0sdI4CfQCKQzi2tdPjQKexXOShdEyv6KJ4ZY5qJp2pbf3OIJ22sPfhKtJ9cL/THmR6afsleGYLt5F8kBy7kTbP/TnE84J4XDyaHsIQh6JZAhKQgAS6TkBFokOkrB2/P2vHr+xUeQhi0PhvoGPa1ulNHWaj6MF7okiEzlgolhoczGHZ0g6+n3ATt2GfSmWv6Ch4FAJcvsUz/Lionfe9I5CmSERTpEzCc/sgltv9JGrvvQQkIAEJSKBTAqVfitEpoKTwLFn6C4rDnvySnFuyo42fxrKYt9E5PbWlgHruiEDoXIUI6GCNbd269VObN28+saMIKxaY43LnjYyMbIxnm3fisXE7zYMlQJlM56OJV6F0hOf9dyyV/KfBSmTqEpCABCRQFgIqEk2UJJ2mXTmq9TqWLXXtS770Y29l5Hb3JpLXS2MC2+krXQrTun0SE7rC+CwCX2L+CB+Ae0njqPTRDIGVK1duYonT/8H9EXH/dFh3cCRsR8v74nFq7g4B6rCDw2xSuCi7Mzy6tztcjUUCEpBAVQl0PqReUnIrVqxYQOfzdrIXPlLWlVyGxpuInowCcUFXIjQSCQyYAPuCtjHanXSgwGPopH57wOKVPnm+j3LM3LlzL+oko8xSbGGWYk4ncRhWAhKQgASqSaA7PeQSsFu4cOFBjNZdw292N7MTdAd+v6ShPrSb8RqXBPJCIIxwx2UJS8Z45p2ViIPpgTlt83urSVFPfZ1Bjie2Gk7/EpCABCRQXQKVXdrEcqVDWa50FbMNw92acag9RjTI4RqlI9VVpaQWv/8lkCcCvD+H8LxfG5UJhdxBiiiQ3t4/hejP7zQJyvEJ7P+6L/XW1Z3GZXgJSEACEqgGgSo19vNoJFfRWC7otuIQHpWgOTAKeyMno4TTfHZU4/ExlxL4OwGWON3ACqf9ojx4Jc5mhPtlUTvve0MgaVYopBTqJeq7Vuv5N7Is7e29kdRYJSABCUigTARKvfQAxWEt0/5joZHlN8IoaVeViNBIozx8n0Z3Oh2mGSgRB/BwqESU6Q0xL00R4NnfP7wPUc9tdGCjwb1vgQB1UNoeh0tC/UTRrG4hurdRb/6wBf96lYAEJCCBihJodaQqt5gYEX0LisIbELBrm6OTMkuDvB2lYRfc1ia5ayeBqhJAWf8geT85mv/QiY2ave8dATr/F6O8HR1PgcGOP7Ncae9gj5/w/0b8NRxEoq4boa5bEI9PswQkIAEJSKBGoKiNfFimdBON4Yp+jHqGBpVvPezLtx5aGdWrMfa/BCpBYMGCBWcNDQ29NJpZFYkojd7foyjsSKoT+ej4Y5k1ujAqAXXoTxh8uX/ULn5P3fcHlIl7xO01S0ACEpCABAKBQigSNI7H06B9nAZyJr+elxxphQ83XUfDe3DPEzMBCZSIAO9qWJM/mSPepRvoiIYlf159IAD/l8L/rHhSlMMY5ZA4C0GYzxLmWfEwNTNBP0fYZ9fM/peABCQgAQnUCPyjxa/ZDOg/S5OOpTH7DL/liMC//olGQxk2Jf6A6f+Hk3bdOu8B4TBZCRSSAN80uJ1vG+wUEf5GZiX2j5i97TEB6tJvsPH9cfFkqOM+hEKQ+FFGlIkTqHM/EQ9TMxN2HWGX1cz+l4AEJCABCQQC/eutp/Dm+w3LOIZ1TYpzT6xpFMMm6auZcbhfTxIwUglUlAD7JB5L1r8ZzT7LAg9ev379dVE773tLgHK4gRTqTtEKKWYtNeNI7F2Hh4dvTZMsVJsoE0kfH0wLor0EJCABCZScwMAVCRq8ns8ABMWB6yZmHBwZLfkDbfYGTyD+TrMO/+C1a9eqSPS5aOLlEJKnHlyLMhCOqF6XIs58Zic2pM0IE34r4f0+Tgo8rSUgAQlUjUDimtmiQwhaAzMON4XRt/Cj4ZuhElH0UlX+ohAI719UVjb6/jZq9r4/BCiGcIpW3YWCsIxN1jfWWdYbRgh3Ur3VP0yEH0ZBWc/yqaX/sPVOAhKQgASqSqAUMxI0fNs2b978SH6XVbUgzbcEckRgOp3Nuu+pZC2pyZHcpROF2YXEU5yoM1/NAMsZaRlGUXgg+yx+jHtiG0H4aYRPdEuLU3sJSEACEigfgYE3BEnT71mYacDC9UdmGML0vJcEJJA/AlMUCd7ZV9HxfH/+RC23RMw+HMPSsoviuQyVaJipjdvHzRMKYWI70Wwc8Tg1S0ACEpBAeQg0bEhyktWx2DIllYicFIxiSCCBQFja9O2oPZ3ZxM5o1I/33SfAgMvFfP9myklNLFGazmzFpY1SpN6dERSGJH8hjvjMU5I/7SQgAQlIoLwEBq5IcKJLOO610RUarLGwCbCRR90lIIHBE2CPUp0QmFOX0dR51NB1AqOjox8i0m/FI0YPeMSee+45N24fNzNzMTtFlwhea3XzEfFwmiUgAQlIoPwEBq5IcCzk2i1btjwpo6GaLAUavnCiyBhKxZQPLk168kYCEhg4AUbCHxMVgnd3GkeL/m/Uzvv+EWBm4XFJMwsjIyMb2Q/xgAaSjHJE9yL8rE/zR/l+n3r55DR37SUgAQlIoJwEBq5IBKwbN268IGzco6G7vhHm0CHheikKxTY+frVXI/+6S0ACgyEQ77jOmzdvyWAkMdVAgLpzyhKnYM+ysx+E/1nXmjVr1qOMLKJMt2b4C6dELchw10kCEpCABEpGIBeKRI0pysSBYS8EjdVozS7tP43iTL6g+2cUijem+dFeAhIYHAHe0ZdFU+e9Pgqz3yCIQunjPXXrf7PEbHs8ScppNvXox+P2SeaJZU7169YiHpmVWE9c+0SsvJWABCQggRITyJUiUeNMYzVMg/e0mjnrP43g6TRcU04lyQqjmwQk0BcCdZt03XDdF+aZiXCk6z5JAzXUo8/PDBhxpH6eSRypX8AmrptQKF4cCeKtBCQgAQmUlEDeT1IZ4vjC39ABaXhKEw3bzTRw+5a0nMyWBApJgA5lnTLBx+m233XXXbMKmZnyCL2Icrkznh0Gb25jb8tucfs0MwM4n0FpeE6aO3XyedTJT01z114CEpCABIpPIO+KxDhhGqx/5+aTNFqZxGm4VtNw7ZzpSUcJSKBvBBgI2M5AQN3MZ1i+2DcBWkiIzvUX8f6MFoIkeqUeauobDYmB+2RJXt9DUq+OJ4cycRjKxNVx+zQz8fwOt4PS3EFxOXWyJzqlAdJeAhKQQMEJ5LJBT2NKp+R39ElSG62JcBvpqCzmfltaPNpLQAL9IcA7ux/v7A3R1Djy+cmc1va1qF0e7ukU182edCoTx65ewTccHtppPL0KzwBN4levN23adOTmzZt/0Gy6xLOeQZ7UTdYoE09BmTi/2fj0JwEJSEACxSFQN1KYd7EZKTt4YjN2VoM/jw7BKB2Yo/OeH+WTQBUJsE6/UAMY7ZbR0NDQQ0Jnvd3wfQh3VFIaHGLRkpKHkrAQZeHSpLiCHUrGeXA4O81dewlIQAISKC6BQikSNcw0XOFrq3+omZP+Mwp6MY3XW5PctJOABPpDAOX/RlK6LpbaeTFzaY10osc/2MZ3GD6Qt0xSj17GUqYpeyWCyNSdl7UiL3EdTVyvSQtDnC8hzobHe6eF114CEpCABPJJoNAjgzRMn6CBOiELLQrHD2jkjszyo5sEJNA7Anzw7FpmIf4pmkIe90l0e2lTNL/hnrool3snqEfXBeUhLi+KwVIUwdvj9llmyvr+lPVP0vyAYCP18fw0d+0lIAEJSKBYBAo5I1FDTIP0fBqm59bMSf9pII+gg3Bzkpt2EpBA7wlwStMh8VR4J8+J25XdTF00PjtBPh+dp7xSjy5Nkgdx1ybZZ9lR1j9FAflKmh/inIfiEmapvCQgAQlIoAQECq1IBP40gueiTOzDbdYXV/em8Vod/HtJQAL9J8Cprzv6n2rLKX4pKQSbpncOMyhN/IboRG9IiiNqhxL1nXCaVdRu0Pd08E+My4BdUHyeGbdvZGYW42nUye9P80e0+1IfX5bmrr0EJCABCRSHQKGXNsUx0+itw27KFH3E36bh4eEVq1atGonYeSsBCfSYAB3HM+hAviqaTJGWN6EIPY/R9s9E5U+7J68vJ69nprnX7Ols52qpE3KPIXdNvPH/iBgGa+ot63ykG6iPH4Prt9J85C3/aXJqLwEJSEAC6QQKPyMRzRodkzBFvzJqF7ufu3Xr1g0TDVzMSaMEJNArAhs3bmw4Ut+rtFuJl87t85L8s+7/f1j//4Ukt7gdHe8PMDOxP7/MI6jptI8vdcrL7AQzL1M+RhcUC+rLz8bz2IyZ+vhCfqltTMg/yksRZqqaya5+JCABCVSSQFsjTXknRcN3LTLWbe5MkPndNHKvS7DXSgIS6AGB+Ig3nfa/0uneswdJdRRl6NyGTm5SJMxM3MHMRNasZ10w4voAUb2szjLBkJfReeT9GfIeFheRujKRR9xfijnsixhJQRo2oW/jORhKCau1BCQgAQnkmEDqaFGOZW4oGo1e2Nz54QYeT0Hh+HEDPzpLQAJdIkCH8ZhoVHQsO+mcRqPq6j0fzNslLUJmJnZqZQaBDvLLmZk4mrynRTluH1hQH40x63FLpsceOyLv/ZJkRbZwetOsNpPfSJxPTQtL1mehaGwh73dP86O9BCQgAQnkk0AuG/JuoVq6dOkzaMC+2CC+P6N47N3Aj84SqDwBOpO3AmHXdkDwHo73pEOHORoe6/vQeb0mapeHezq130FpSD1dKeQHuVsaiKGz/HWy//hG+Wsn7kZxtuKOnG9FzlPjYVCIrmYj9ZTZiri/NDPx7kO84SvnidzId9iPMQf3LWlxaC8BCUhAAvkiUNeo50u07kizYsWKXVn7ezMN2OyMGG9Gmdg3w10nCVSaAKPw9+Ujjz/vNoTQaaaDuoPlQvsQd9b+pm4n3TA+Or6nUW+8Oc1j6PjCZK9169Y1LffChQtPREE5h3gb1r0so/ohXB6Wln4v7cn7ekRcEE8DmU5FprfF7Vsxo5CGfRGJ+Z9QJhLdWklDvxKQgAQk0B8ClamwabzCmeiJ56VPoP7r3LlzD7zllls29ge9qUigOAR6pUgkEQidSX5jbND+IoMALR8/mhRnu3ZhGRPKQuIIei1O9KCTGKn/WM3czH866r+io36vRn4Dh1ZnPhrF2Yz7ggUL7jk0NPQL/NYtZ+qWPOQ/dR/KhHw7Mbgz5avbzciuHwlIQAIS6B+BzAayf2L0PiUapWWk8peMlPYoyskyGXnQSQKFJxAG6+m7T6cz+28MAIyFX+h4hh92f+tnBlEQZjIKf1tWmsh6DgrHV7P8xN1QDu6NAvLOuH3cDIvxk42Yyfh03K2X5g0bNvyGOnPneBoT8vwsbt+qOShHKCVZS5jugGnqvopW09O/BCQgAQn0hkBlZiRq+OiMXE1jeJ+aOf6/WyNu8Xg1S6DIBPo5I9EKp/C+0iEfo7N//MjIyLmthG3FL3smPsWSpOOzwiDDFpb9hDX+LV3USYnLiOKRkFX633c0fWJUPHw7ZpS4zxLuWfGwHKO9G7wzFax4mCQzeV9DfRwGeRIv8vwm8nx6oqOWEpCABCQwcAKVUyQCcRqvM2m8Xp5Bf4zRuMrM1mRw0EkC4wTyqkgkFQ+dz2A9xrKoa+js3jfJTzt2MHg6sw+JX7+uxYdSsyPMYtTMzf5HUfkiisozGvkPeSOJN6Gw9K1zHWaE4nIhR9eWXFEfb6Y+Tt3DRl28iPTXx2XQLAEJSEACgydQSUUiYKfxejKN1/kNiuBhNGI/bOBHZwlUgcBevDPX8c7Mi2X2vbwjr4nZjRtZjvMCOt4fIcwMfkle+mIXOr10vr9H5/vYThNcvnz5Qo6HvSsrP510smHcaO/AeBZI4xeM1HdNScrigiIR9ql8Lu4HpieiNH0ibt+OmXxvD89JWlhmex5M+V2Z5q69BCQgAQkMhsDgWvfB5LcuVUYBlzIKeCuWw3UOEQMN9ltpsFNPbol49VYCpSZAhzK8K1OOf0WRaKkeYZ/DCBt54wpJX9iFTj6d0jPXr1//qk4SZHZiR9jHkRUHHe0D6GiH405buoj7J8R9/0aByEqYnXgWHezPN/LbqTsd/bEk5anVss+SgzQaLTt9C3XxaVlx6CYBCUhAAv0lkNkQ9leUwaVGA5Y5tY5k36PBfPTgJDRlCeSDQMoylx2bN2/ej9+fmpWSd65u5D10irnG/9Bh7Uu9RCd8jI7+I0n3kmbljvqjw9/wRCeUlpfR0T87Gq7Z+zijtHCw+yod7OPS3LthT16XoNysi8dFUZ3H8bdd2xRNOm8nnTfE06mZyevl5PWImtn/EpCABCQwWAKpU8mDFau/qdMwzaGBGs1I9VF0oH6U4a6TBCpBgPdkylIWOpMzZs+efVMrAOgs/kfMfxjxXsK7OCOMck/8XkFHnCT/rmXE/HdsRIbwNemLg3IUlIJWIwx7IZDvz1nhmPE8i7i/neUnzS2wQNlZneZes4fbk4PSwQzrA2t23f5PXm+nGK6Ix4vdU+bNm/emuH27ZtL5L+L8dVp48vow8np5mrv2EpCABCTQXwJ9Gfnrb5baT40G6jYaql0yYvg6HZwnZrjrJIHSE8gYKT+Z9+O/mwFA5/pEOvLxby808+2ABey9uJ0OetjQzOva/SoM5eA2ZhF2ayYfwQ8d+A8jzguz/NM57mRz8mEw/2kzmWX/xiks2/p/WbJ04oYco8hR920J4hsj3YeQ7o87iTsalnT+Sjq7R+2i9+A8AUXrU1E77yUgAQlIoP8Eut8K9z8PXU2RBuzTNGDPS4uUBuwCGrAnpblrL4GyE+AdOY535LykfIaZhCT7JLuEZVLNKBJJUU1j38XZdOZfjFzjV6KnFi1D558O8iV8UyEsf8q8UG6eMGvWrAuyPIX4wixDlp8sN5SvhvsyQvhWyiArvSQ3lKaXwvmsuBtZGyVvqXvN4v6bMZPfz6FsZn2Q8H/J69ObiUs/EpCABCTQGwJNN/q9ST6fsdKAPYMG7Itp0tFobqXRnJ3mrr0Eyk6AzuQldCqPiueT0fw1jOaviNsnmQm/nXgmO9aE3UHYlo9OTYo72BH/AbzHfwiaRZqfZu0n9lMcj//PZIQZQsna0ig9lJPrGL0/OCOeVCc2qb9s/vz5H2iUJeTdn2VCN6ZG1IEDStvHkOPEhChST/BK8NuUFcrms/F4bppn6uK7qIsXp7lrLwEJSEACvSXQcQPbW/EGF/vSpUtPp5F6Y5oEuHU0upgWr/YSKAoBOnmXIusj4vLSid1OJza+/CXubRpHqe6O8vDXmkMv36nh4eHzWMsfjnzuuM6bUComFaCa/LX/zcwcEEdb35uIpNFwozcKy7+jsHy6Fqab/yn7W4mv4xO8mpGJ2Z5lzPasyfB7BzMTff1QX4YsOklAAhKoFIHUxrBSFBIyy0kkp9LnmDKFX/MaOiQ0pttqZv9LoGoE6LwdFTr/8XwzCzATRbzlbzaEdyoeV7fMfIn5KWFZUVj2g/IykiB200mRv/Duj4Ufsx5T6gCUqBlhdiUrQuKYwexFpp+s8KQxkzylzpqGsMz2fDIrjk7c4Ji4h4Q8XdtJvElhUYbWond9NMltwm4nyqLr6Wakp5MEJCABCUwQ6FnDXRbCNFAvJi8fyshPGFy8e6+WEWSkq5MEBk6AjuN/0v9/b1yQZmYX4jMSIY7Q0Y/H1UszswcNR/abST8oJswA/I39FJOHNbAE6FcsAbpXo/DMlixYtWrVSCN/ae5BIclSwmAaBoymKHxp8TVrT7ofJ93nx/3DYl+Utpvj9p2aKatT0L/elRYP6f6GdBvyTguvfWcEli1bdhxtYeLeqQ5iXslSvgNXrly5qYM4DCoBCfSQQF8b7R7mo6dRM7p6CI1UOJIwlRfuniLS01Iw8rwSoMO8iQ7znLh8jMpvZs/D3Lh9zcxSo905NnZyaVOw77ciUZMl/G/UIY/6zbqnLgjLHsOyyHcEf83EixKyhZH3KQyz0om6NVpORQfvUQx2XBQN0437tLz1qhzJ52EoEz9Lk32CvTPtaYB6aM+gWzhCuRfsw9HQbw+rBHoovlFLQAJtEujFS9+mKPkNRgV27cSoXupSBCq6T86dO/dB+c2FkkmgNwQYhQ/Kws3x2FlaM4eO5h/j9jXzxo0bb+H+mpo5/Gep0L9Gzf28ry19osP90dAhbTftMDtAp+rt/Ma/TxHiJbopS6Ci8bMHYHbolEftWrlH5pDGJWlhEOl7aW4d2id+jI68n9xhvInByefPs5SUwB6OmawTI9ayGwR61Z+YzrP9Rp6pm7shpHFIQALdJdCrF7+7UuYkNhqwmVRoqR2MOXPmhI/Wde3UmZxkWzEk0JAA78a+SZ7o1+0flg8luSXZoXwkWffVjtH7F9aUCmYK7sp65xsJFvZCBIUCf7OIN1NRCJ3gCeXjfo3iTXJH5mNI4sYkN6KeNiFHknPbdqR5fgqfDxLpwrYjbhCQ5+3AtKqYvM4krxsbRKFz8QjsTblu55e6d7F4WVJiCRSfgIpEi2U4MbqYpkyMb8BmTefkOukWo9e7BApLgI5d4l6i0JlmpuG/m8xY6vLBJsN31RvLjRbXlIpGikBWwqEjHzhk+am54e2njKq3tYyDEfv9kTOtfgrLrLZzCtJBtbS68R8+85OUCdK6uRvxp8RxPWk+KsUtWM+lwxm+9n1Ahh+dikcgvEMvpWxX8rtb8cRXYgmUj0BTDVv5st1ZjiaUidT1xqwXr1v33VlqhpZAMQjwXrwkrRPLTMOL6FheHM9JUgc07icvZjrpM8OymvDrtdwoHm8NMzl0hJe2mv+JZU5pMxMzKIvftRpnA/+bKPdvxf2Qh6Xk4fa4fbfM5POisFGdskib6ZmOUvaHbqVnPLkisAfS3Eid8plcSaUwEqgggVyN/hWNPyMiFyLzvyTJTcP6bRq6xyS5aSeBMhPgvUgdEQ/HokY/OkdH82o6e/eJ8HgmHfUvRMx5v30znZnTwoxDry6YPQdmn201fpSQ36M0HJgULihCYUAkya1dOzj8EQ77x8Mj/78g/3fi9t00k3ajk6t6V0DdzEiB4+K9DwrdJGfe470x/7ndLFGmb+R5egvhM59THuW/UYc8kb2MV7abluEkIIH2CUy+9O1HUe2QnOh0FRXZA5IoYH8jjfWUhjXJr3YSKBGBsMQvbZR4Gu/FcbwXX53I78n4Devpx6+4olGzL8J/Tq9ax6bpJb1QKhiY+AIDE89slUNWB5ty2EE5LCDObh2tOYeynBIX6XRdaUnikJVX/I/xbN0Dheb6pLDadU6Asv8FsRxai4li/wXP131r5nb+077uRTxXEHavBuGDInkBysRxDfzpLAEJdJlApqbf5bRKGR0V1wPJ2HVJmaNi24/OxUuS3LSTQIkJjE0s/0nMIu/F+XQ6zplwrNtXwchiYQc3OL1qKR2n8aVPdFqb3mCeCClmCZd/o6Pc8jIh5AmnOSUqdZRD+CheNzclbybOQ2KiT8MunKR0dty+22aQryDONEbTmZ35A3I8t9vpGt/fCVDMb4uywDw7am7nnvb1L9QldyPs63iOs07jCs/5k6lX1jHLeVQ7aRlGAhJoj4CKRHvc6kJR0R1MJfbNOssJA/slzqbx+s8kN+0kUGYCjKJnHQH6ApTsPyXkv7CKRDQvjHzPCspU+MEhdalXNEyj+7/3x3cag9tpjfxG3VEmZtLJTtwrQJzj37mI+u/kno7fbwl/czwO0un5gEr4Aja8w56S9fH0a2bk+B9mjY6smf3fVQJx7vegYx+UgI4vyvXdRHIA7ezNDSJbgtJ9MW1umPGc1cCvzhKQQBcIlKLR7gKHrkRB5TVKQ5VYeW3evPkhmzZtCsfDekmgMgQYHdyPhv2GtAzTMQj7I34ROrS1K3S+a/dl+s+eha/D4vHRvLabP7hN27p16x4T3+JoKhrqp9R9BMQXljl17exdOpBTlCfS6NtSz6y6OMDiGRvm32hT4PTUNIF4uVPmXf/KOWm8nnjfzHvUaMZjBH+P47m+rOkM6FECEmiZgDMSLSNLD8CZ8+EkicRlBHxj4oe77LLL/PTQukigfARY139jlmJAZyCsq67ExSzFE+jUBCVpbzo4HeU5KCPhq+BBOUBZO6+ZyEg7LP9ITJj4ZhDPrc3E04wfkqlbshbCkMZ+y5Yt6+rRs2mykNehtLyGMHRGt8LuCWnhtW+bQHxp2aVtx5QSkPrkncywhbY2zH5lXfN55i6lrL+R5Uk3CUigMwIqEp3xqwvNGum/UcmFUb2kxno6I4gb5s2bt3tdIA0SqAABlveckZbN0CmOXnzn4NNRc9nuqSP+HBSKoGB1uuwJduGI0+PCSDAzHg33ZZDuPDrYf0piSjy7BsUkya1VO9J5SVJHnvx2++jZVNGQIbRv303zALoLyO8H0ty1b50A31AKHfzJC8b7Thq6eDOxjO0QnrFXEu3mjKhD5fI43o9NKModbfzOSEMnCVSagIpED4qfZUwPTouWc8//nOamvQTKSoCZiVfTiTy6mfyxKbYy9RJcZkwoFP9Lp6gZPKl+AregUNA53k6nKa0Dt5kO9j5JnfwQcVBMCNtQIUkVIuJAVI+LGCdvib/RSPKk305vYHsscfwwLR5kfBnMvp7mrn1bBOqUUfg+vq1YmgjEs3wmZTyX5/nnDbzPQVH+ObKkKpYNwussAQmkEKhMg52S/55YsxfiKiJ+YVLkNFwzaeinfJgrya92EigTATrNlzKS2PWlDmVgBJun0ymaPjo6ukunCgV1DH2mGeFjXTvYmP2lJD5htD5NmQiBCRuO3OzoooN3IcrjlngkRH8wsydTPmAX99ctM3I8DDnWZMT3eEbSm1JyM+LQCQIrV64MswM/icG4W8zcdSPP8/2I9Fn8phw/HEvsUSgTI8uXLz8yZq9RAhJok4CKRJvgGgWj8fooeyZOTPJHQ380ldnKJDftJFBmArwTR9OpCyeqpF68H6luZXcIyyODQkH90ZVlT5wa93TqmnDS0/VxdhPKRGLHizI4PCgi8TCtmlGQ5hJmShooE+FjnY02y7aaXKp/5AhHw6Yuq2Km+GI4nZIagQ7NEhjj2RmJekZhPTVq7tU978zn+c0j/tQZqIm057HH4jLK+/u9ksV4JVAlAioSPSxtRl8/QSV6TUoSe7AW/FUpblpLoLQE6NQdhzLxgowMPifDrTJOcBpf9kQdci6/jvKNQnFAUCjCj9mAyWM6USbCnonEyOkQhu8/dKpMjDFDe1JceKIOx85OUTDi/rppppP5T2T1zIw434VM/5fhrlMTBHi3PxP1RlnvEjX3+p5yfhiK6tGk2+j5OoL3YYSP3j2j1zIZvwTKTKC6Q399LFUap/Oo1I5LSfKNVHxvT3HTWgKlJcAo+Sgd3FlpGWTU8EGcdBSWCXpBgE7PYjrCd4ROeLeuCSXiqcT3FeJNjJiO4cUoNY/sJE1kD9+RODseB+k/GWXma3H7XprZo3EMHc2L0tJApjuRaac0d+0bEwgKa9QXTL8G0ydH7fpxT9t7MY91w2VryPdT5HtAP2QyDQmUjUBiw1G2TOYhP1Roqd+YQJGwHPJQSMrQdwK8F1fT0IdvSUy5aNyn0bj7bkwhM20aneEddIb7xoayWEdZLEsQpWmreOeyFnAQ9R+yBOXliTUZEv5fjVyHJdhr1QSBBL4/gudDmgjadS8cOfxABiW+Tz3TaCndJp7zU3jOpyi8XRfKCCVQIgIubepTYVKR7UZSicfUhc4UbpZFn8rCZPJDgEb7vox4vyNJIhr+sPylbmQzyV8V7WrLnmD3saBw9fqiLJZ2epoTsu6fJCedznOS7HtpR6f2Scjz+Yw07suz9+kMd50yCPBM/iDmfHjM3Dfj2rVrr6KeCXt1vs0v62WZy3N+Fs/jb1j+t7RvApqQBApOoG8jWgXn1DXxqaTC0YpTlIZZs2adunr16rd1LSEjkkCBCPBepDbwdErG2KS9a9iIXKAs9VvU2XR8w5pw+kLtV+t0rg8j/M/T4uBUqe9TDg9vN3OUczj69eB4eL6x866RkZHXx+17bUY5egEzO6mKDI9e2Py+S6/lKGP8Ce/0wGYlanwp76Mp7wswZ34clnLfwjtwKgrne2ph/S8BCSQTaL/FSY5P2wYE+CDd/fgi7U9TvB1BxXV5ipvWEigtATrBO2i4M+sjOpvPobP52dJC6GLG2H/ySwYn7t0A6ZQUgyLBbMfVYSYoLSydrJ/TuQ7HbbZ1JXQwQzxhU/eh1H+/bivSDgKx2XZP8vSXtChw205+U/fypIWruj3P0G08Q1ElbIzynTKINgBOQzyD55PuY/ll1jmU/U0oHkeuW7cu9fkYgPwmKYFcEcjDS50rIL0WZuPGjT+jcjo+JZ1Pp9hrLYFSE2DGYVujDLIx+1z8hE27Xg0IMGvwz3R+x4+RpfM2naWVdzQIUueMQvHgOouIgc7hYWGPRsSqpVviThrlnYH9NS1F1CXPdBJXwmjntOjI70w6nhvS3LVPJkAH/KiYy3SUto427cfia9c4Snk/nnJ9NBFkvhf42Zfn8gbk9oTFdmkbrvQEVCQGUMQ08P/D6OpzE5LejwbrrAR7rSRQagIoCfFOx5T80qiHk4vcCDmFTGMLTr9aEhQKBjH25ZcW4LYwGxEc8X9l8J/mkU7idI6v/nGae5Y9abyWztkf4n6IM3yZu+/LmybkWM3/k+MyRczz6UyuWrFixYKInbcZBPjS+jqc10e98OzlZmYHBfIinvElyPcNfqmKMfXOEHKfwQzLzXzIbvdofryXgAQaTOsJqLcEaJh+SgUVXyKwlcqt0ekSvRXM2CXQZwJ0IB9Kkk0v6+O9eQQK+WV9FrOSyTVY5nQe5RCOj235oszD4RN1dR3lOtCTupApnCwUnsNEJQr5xsivA3BNljbPzg10xPerec8rP9riw1Fuv4as4cOFWVdQOMKR7e/M8qSbBKpEwApxgKXNiMj9E5IfDmtLE+y1kkBlCIQOB1fqcica/P+j0/fuygAZYEYph2ekJU85PIVlTnVfMk7zG7enMzYnbkd84aSuphXKePhOzch0Bb/UdhH5uvGRvk7FLEx4lK79o8IGfnTap3ygMOpnEPe0xT9C1rC87XP8UmcncAvPxjvIQ5iNG+LnJYHKE0itMCtPpk8AaKTfGk+KunaXiZGxuJNmCVSCAO9A+G5BWFKQug4HEK+l0/mrSgAZYCZZivRlRmtTj8NkRdI8ljm1VQ4U71fjWaPsH0r9tzhu308zykRYBpb47CFfUCbC6XteTRAAV92x52C9VxPBBuKFcn828u1H4rdkCYCfB/EMXMlSp4VZ/nSTQBUIqEgMuJTpLL2ZSmlKg4XVwEblBozE5CtIgL3Wde8Az/8S9k0cyvsRNuHWuUXx0Em5Vycbf6NxeZ9OAGWCPtZ45zrREydE3YvOf9Im6kT/NUvK97ik+g/3sAn2gJq/QfxHttChTLx47sJ+ju18b+ABiR60nCRA+X5i0sAN7E6MmvN2T7n/iWd9D+T6b35Zdc99OcTgKvzULc/LW36URwK9JqAi0WvCTcRPR2nKCSlUttPpIL29ieB6kUDhCaxfv/4KMnFnLSOhozZ37tzxBppO7Aw6I6tqbvH/YeMvo4NZyxHiQTS3SYCO039mBH015fCbDPdEJ8o2cakL9d/PEgP0z/Jm8ruM5OpG1CPJz2BD8VXMxgzsY2sRWXJ7y7tcN1tFeU9Z0pZH4VEmTuYX+kh/yZDvYBTK6zPcdZJA6QmoSOSgiDkhJYxqTNkXQQX8hhyIpwgSGBSByQ2vjBLuSgfkU2mC8K6oTKTB6aI9Ct/7GPg4LC1KiuEQRulvSHNPskdR/DhxTtkPg4K4GMXk00lh+mVH3byOzuRcnr0p8tVkYDYmKMFeKQTYf3AO/OpG9inXwnS+Kf+7kbWwubouD5Hs7sWeiRGWOd0jYuetBCpDQEUiJ0VNZbUbotStu6VRDsdd/iInIiqGBHpKINbXmEYHrS49lIkT6HA+rc4yYgjKBO/L2Pz58x8Vsfa2ywTo+F9NfTWp5MWjZ5Q+HGP94rh9lpmR/z0o/61xPxTp8+J2gzDz7GXu1wnPHZ3JPQchWxHSpBwfH5UT885c0Y/VRZ1zd8/z/gae68XInTgzyrM7j2f4Gp6Dx+VOeAWSQI8JqEj0GHCL0X88wf+hnl2dQEWrMhJIG/GbzCud2K8MDw9nnuWP+3fnzJlz2mQgb3pCgH0t782I+EOMOn8zw73OiQ/o/Y3O+oF1lhMG4gnfeBj4hXxhid3f0gTB7S8sx3p+mnuV7emAx2d0FtHxDt9wKMy1Zs2a9cyu7IrAH0kROizZ+grKxH+kuGstgVISUJHIUbEy6vFCxFkTF4kK969xO80SKBsBnvO6fQ50LhMb5FWrVo2EEXE6bqkI2F/x5lRHHbpCgGVOr6EMnpIWGZ3Hx7LM6fY09wT7P2H3jrg98SwnngfF7QdhRpkIo+h1a/6jcrAc6+MoPmdG7byfNo0O+HfjHHjfL4vbFcFM3fMinsm3IGtdfTUh+2z+fxBl4nVFyIsySqAbBFQkukGxi3FQQT0rKTqmzV+QZK+dBMpCgI5p2Ng6eaEMPHfSkHCzadOmoHinXmG5CRthE0e5UwPp0BIBOtbns5RsXlogloPsRDn8S5p73J5O2n+hnEzREInnx3G/gzIj4z8j4tq09KnDX46bG7CnAqorQzgVZmlTPCsoRqfxDLwS+ynL8bALazLfSZt9RjycZgmUkYCKRM5KlQrqe1RQ58fFYqTLYwbjUDSXmgAdjdR1+CHjW7Zs+ejo6Og9E/qdk1zYZ/F7RohDx86rRwRWrly5iWVOn8qI/kLK4OwM9zoniv2IOosJA3F8MMl+EHYoUMt57kbT0kZ5uoJlTo9Mc6+iPQrYQ+L5pkxfEbcripln4Cye1efyHGxJkhn7V/EcfDHJTTsJlImAikQOS5MK6pmIdVNUNBrqE6Jm7yVQdgKNFImQf5Y/Xcv7kvrxsOCHeM6kw/K9cO/VGwLMJp1Ax+nVabFTBi9hedJ1ae5RezqcPySu8B2Juos4TiaOr9VZDtDAczeMnN9PE4HBn+/x3L0vzb2C9mGm6cpYvo+MmQtlZODvSxwA8TCETpqZCHl5Bs/AVbvsssv8QmVMYSXQAgEViRZg9dHrlvjoDY2oZdXHAjCpYhGgUxc2woaOSuLF+/NIGvSkNc2J/rVsnQBlcAacD0kLyfKke7DU7KA096g9cS1JKk/ieMKCBQt2jvod5D1yPpz0X58mAzxeyXP38zT3qtlTpnWb1eHzpKIz4Ijgn7K8byfykniiE/YP2Lp1649233331CWARWeg/NUmkOvOKdOCH+V3FxVx4SubNh6zWwkzEg3Hmsszo2bvJVA2Akmdx2bzGJQJRgezlAm/NdEszDb9MUL725GRkdPSgrPU7HfU52FtecOLsvxogqfpxHFbgv3ArBj0eReJfytNADqS9yXPd6W5V8med/SJZcxvWN7Hsx+OMP5DSv7uzZ6u1E36KWG0lkAhCORWkaDivQ8ET+K3kIr4TYWg2X0h4yeY3K37SRijBPJDgHf9i1FpqAdOi5ob3YevYONnygkxtXDErzJRg9Gj/4y+voUOVep+BorgfewfuKhR8oz0voh9MJ+K+5sow+Pj9oM0o0w8jjz/Mk0GZF7Is+yMGIDgVDdyz2Dhh9O4Fcx+O8vZ7o/M16TIvT95XVek72ek5ENrCdQRyK0igZR7RyRNnS6P+Cnjberoahkza54kkEAgc8N1gv9pdOqOpbPysiS3YBc6ojToY6Fjx1Kb16b50759Aow8v5TQj02LgQ7XMbNnz06acagLsnHjxhPqLP5h+OQ/bvNxR54PRZK0bwxMPnc8e+/Oh8SDkYLX722xlPeLmQtrZFbiLk6bC5vK0/bOLOGAiJupe44sbCYVXAIxArlVJGhohiKyDkfuK3NLZ+h30cxifkLU7L0Eyk6AeqCtLNKpO5tz6u+eFTgoFCyTeXdNqaBj2/QxpVnx6vZ3Aih0F/JLLcB58+adRIfqyY14cdDE8rifUHaU25fj9oM2k98XUU83Wr7zWmS/Y9Cy5iV9inJmXmTphhy33HLLRp6DhxPXuSnxzSHP31m2bNlzUty1lkChCKRW8oXKRUmFpTP0tVjWSlXhxvKmUQLTWBffNQosjfkjDXpTMxqhY0rH9sKgVLDsJldr8LsGZDARjaHQfSMtabCfD+/MmQlOhFrLc1H3DYKJ+J6WFu8g7am3v85z12jwazHPWvce9kFmuMW0KfO0E45ajCnf3nkGnstASNrs0xye6fDxwlfkOxdKJ4HGBAqjSPDCXdw4O+XzwejWG5KxAwAAHndJREFUlmiuaHw+EzV7L4EyEeB57/pyPhr0Z7cSLY3/LkGhoM4JH7T7UZn4DiIvKHRhJvUlaWnD+yQ4X5bmHuzZ+3J4UhlSTttRRA7LCjsgt/CNifc0SHt8iR1LYZrafN4grsI404GOHwO8O8KXcpBs7dq1ryO/YflkeB7i1zBK1fs5ROX0uINmCRSJQJ4ViboOBS/cEUwF7lEkuF2S9UGxeHI5CheTUaME2iJAp/NZbQXMDvQ5lsccne1lqit1zjSWPj14QqnYwdInv1Q7FVNTNihzH6JDtX+aZzgfieIW9hikXoR/U4LjDMopabYiwWt/rchz6EA+NkkBikoyZ86c95H3tVG7Mt8zY/ODaP7gcwDmUioSIZ8owe/hGX0h+awbFKwxwP6NlP/Ha2b/S6BoBPKsSMSPyxuiIflp0QD3QN6mlmr0IF2jlEBhCfDhukvp2GV+uC4rc3QEwtKn8KXasPRpe5Zf3ZIJ0KG6kWVOqXU4iH8B39cnh542DSXzdDpd6+PuhBsiXNoSkrj3vpp55i6k4xyeu+uzEiYPS8nDjop+uCzshyx1u8Ym7E/yDDyGX+KyLsr/+cxMhFUXc7KeE90kkEcCuX55qVhXAq1uFoIX8eVUzGflEWYvZFq+fPk9aHx/Tdy1zedhpuZIGqjLe5GecRaTwNDQ0O8ZMd+PZSK0SX+/4jkJtnE7zd0lAOJH0Wm4qLuxlis2Rl/Dh+telZYr6rvvojQcm+TO6P3eLAUKh1DMjbsHRTFulycz+X4v+f7PRjKR/+eQ/8828ldkd1hsh8XkQCZlFzrQiSP2Rc5nXHba890o399iv1PcbcJ89fDw8BGrVq0aSXHXWgK5I5Drijd8CZLj/9ZR4cyOkAsd6ZOpeMpy9nQka8m3KFR/xSWsIx2/mJk5htG9S2pm/xeXAEs6LqBz9BgVgOKWYVzyvHdo4/IOwsyszlE881l12E5wvDNNNurEuqWvwR+DTL9mkOneaWHyYM/y3AdSf4elWI3a3rXkf8ppVXnIQzdkoPz+Qjx71uIir5VQJGr5Jf83cb9PzRz7fx08Do7ZaZRAbglMjgjkUcJwjBpKxNdjsoUK+L0xu1IbaSBdSlHgEmZJzNvCchhG4XaEDlD0xybTJzCbMGsmFx2rf0wn8ODXrgJnXdElkEiAgZBL2beS+gE3At3Be/KviYGx5N34VNwNu3sR5m5x+zyZ2Xx7FZ3EGdTp32gg1zLysoN6474N/BXSma881+2FIq9fLWRG2hSa6j4ovNemBD+IZU634BYdQE3xqrUEBk8g14pEwEOl+3T+xUem5lHxbOZl22vwCHsvAf3LK3ufiil0QgBl4N8XLVq0LSgL/OqUBZYc/VdNSegkDcNKoEwEONb1UEbnz8/I0xd4p6YoDME/y8dOoDM+ZVYCpz9lxJcbJ2ZOnoDi8x8NBJpOvfFz6pNTG/grnDN1Yli2HL0eETWU/X7NmjXrUSYeTD6vTsorj/ZulPudZVUkk/KsXXEJ5F6RCGh5qU5LQDwb++8l2JfRat8yZqqIeVqwYMHWCWWhbnYB+0+GWYWJWYQiZk2ZJdB3AsxMPAVl4qS0hHmljk9zo/4Pg0xTLgaZXjTFMocWKEPnkL/dyUfm3gDqlLdS59zBwNmiHGajWyKFpU2VuoIywUDpYZT/eUkZp9xno0j+kHJ/SpK7dhLIC4FCKBKM3pwJsLsSoB1EBfvJBPtSWdHQrihVhnKeGfYtfKe2FInnq252gZmHoQllISyx85JAHQGejUfVWWhoSABl4mMsdflMmkcUgzFmJuLHYIdjNb9C3ThlVoKO2YfS4sqbPZ3JW2nf5rABNzX/QWaeq8Xk6044pC73ylveGsgTym1K2TUIU0pnyv+pZOzslMzNpdw/R3tUCOU4JQ9al5xAYTpDdOj2oTINp3VMGbngRTuLl/HlZS0rGtK606toPI8Oa4zLmt9+5IuTXw5HJ/g+Iz7h/PKgG/Qj2YGlwTtSS3vyJlhgPxY6Y3RkRjjYIJzT/4Gax0H9Dx3HWtqUy1sZuX1zzez/8hKgs3Q17+N90nLIo/oW6vnTou4TB3Ks5zmpGxTD7zfw+4So37zf08YdST4uayQn7+sXqP+f2chfnt1XrFixK3tkrkfGBTU5GZ2fz/3Gmrlq/yn/Uyn/UAfPSsj7Dt6NU9lj844EN60kMFACheo90dAcxcsUljOFzl/02k7leiCV641Ry7Lc07GqO7WJRvLhNJLfL0v++pEPNjW/gGfno/wK9cwHNpT3+L8ap5o5/KcxHt26deup/G/0Fd1a8Nz/V5HIfRH1TEDq+Lfzjr4hLQGU3dds2bKl7rANwryLMKdEw/Bu7KCOjLcTUS+5vef5D53pKcfbRgUmf1sYCLnn6tWr/xi1L9I9+QwDgwfVZKYTfSyDBt+tmav4HyYnk+/38RtOyf/ZKFwvS3HTWgIDIVA3ijMQCVpINIzCU4G+JSFIOPHmD6wlnDL9neC36FYgGPOM6QaliOLwPjoYk/sYWK50Th6UiFB4XNPCLAAdog00CtMb/egQTec3o/bjPZjBbyZnzc+kYzWnTEpEg2LVueQEeK7/iyw+LC2bnID2HvYj7Rx1J8zrMNcpEmGGgnc+VSGJhs/bPfXBvDDrkCUX+ZsdRvQZxX5jlr8iuZHnTOWpSHlpV1bK/kO0D0/nl7Zv5qUoG+GEq6RZi3aTNZwEOiJQKEUi5JTO1On8+3xCrmfy8pXuCDmmgMPUb/QYuG2Yb0jIf6WtUBy+RaMaVRxeOUjFISgL/MKSoe00Ds+vKQsTysD0oAygBCysdKGZeQkkEOBd+SGvzeoEp3ErRuJX8a4fH3XH/+aoOdxTJ7w1blcUM/XDM0dHR3dpJC8KxemwuLqRv5y6Ty5hnJCvcLPFveBKG3EBm/DvQ9lOeaYn0nsSZX5FRb+C3gvkxtkhgcIpEiG/NDThDOrbEvK+Ky/YVdiXpkJi1Ho38hPtcO6gkbk9Ie+VsmLT4Y2UdVRxeAwVb9/LPSgLjKTtYHnRGTVlIfynMRifRWDWIIwcfbJShWNmJdAhAd6bnbNG5XnVP8WM45dryeD/rPAu1swT/2cyS/3omF1hjBs2bPhbqEsQeFOW0LC4D3VhOBTinln+8uaG3HfkTaa8yMNeiN+xzCvM0IRlzVMu2D2ANufHOBRy+d6UDGlRaAKFVCQCcSrYPfg3RZkILxiVathHUYqLkYmwuXyoFJnpIBOMLo5GFQe47EtZ90VxmFAWxqi4eezqlyKFGQYUu5kjIyOv7iB7BpWABGIEwqg8795zY9aTRmYcn4YyEZaA7BMsqQ7uHf5HL5SRb0fNRbynzpmH3F/Lkn2iKvw1deTHs/zlyY2lZ3V7XcjDiXmSLw+yDA8P3wM5fp8iS/gAY2H3yKTkSesCEuhLR6xXXKg09yHu66iAokt/asltxv5LaPXH1yyK+J88/jP5uKYmO/ebJ0Yqalal/I/isA1lIXyXoS/5mxjMHJ9dYHTzEBJNq7z7Ik+VE6FxnBxZpvw9tanKDwN5Z/bxTqqCRVkYUBjejeLxOp6dP+HvblG/vNulOdUv+m5E8xi7H0H5CEtic3/F8rMZuSu/TyJeaPQBdsLuMurCf467BTP2I+yXOZR2S6UiCZB2PSdQ2BmJQIbR4JsZlUobsZpDA/K8UFHxHq5dvnz5C3tOs8sJIPsXiPIn0WjJ02jUXMb7UGaMVvVMiQhKAxXvZdHZhdhSJJWIMj5Y5qmQBOggLUZRCMs4Ui/agVOo53/FO7133BPv+7/F7YpqDnUWsqetna9laz4sdmDYq2ZRkP9h9t0rRoC2KVwPwPq7MadxI8/3fBTtX7OM79gkd+0k0GsChVYkAhxG57/Mi/QmbidHMePQ0NiXshnvw3RQw5r6sLb+0LifPJiXLVv2QGS7fkLOkJ9/Rfb4MXB/y4OsvZKBvGd2GNpJl+cjbHr+cE1xoFKevn79+ke0E5dhJCCB/hNgtuHwiXo+NXHqyrDUI7zudW0BSkapPuhJPTaXvF6aCgIH3KfD4s/8vpXlLwduQeHxakwgrKs9lmL9RIrXMHD6VZSJf09x11oCPSNQeEUikKFjeDov0WVNUAqjOfvyMv6CCnYrv8tYQrO8iXA984IMYTp+Pb+wrOZKZDuAxIKciRfu30x0KIElSxiWUo4P7DQrxBEUh5dHFIcZjGq+uNN4DS8BCQyOQKjnea//1EgC6sgp9Sf16/WNwhXJnQG0o0P9RlXXSOzHMDi1tZGnQblTVGsGlXYR06Xcwz6Sd/JLUsCCMvFRlIlXFTFvylxcAqVQJAJ+Gpmj+PerFooibGA+kiU0qyc68uET9X05AYH0Lqdy3xaUB9IMlULT61mpSF6B/1JeVIKhDzClE9Aos4QLStijY4rDWY3C6S4BCRSLAAMC+6BMXNKG1AcwaHRgG+FyHSTMrlL9ZSoKVKlDtDcNNY5BZJR6+7ODSLfIadLOvQFup5CHpHIf4nk4g77Fu4qcR2UvFoHSKBIBOy9YWEfYzh6C0JF/CS/fNrT5W1li9OwQX7cuKvEn8VsVFIcJ5eGhVO59UVq6lYc8xUMlOrZ58+a9o4oDSx9Kc1JXnlgriwTyRgBl4pjw7ocBhFZkYx35da34L4pflInZtCeZ9V8Yn5lof64oSr6UM50A7d17cT0hQ4k8hfL+UnoMukigewRmdS+qXMS0hQZmGEXg3XQ2/wOJFrcqFS/mrvzO5SU8t9WwvfZPY1C6D+5FmdHQT/kIFWURZhvG6DyoeEVheS+BihOgAz2D5ZC3U2+EU20aXtSf0zku9kV0wj7c0HPBPDBT/WhEns2A1aaQzwzxD8fPZti5sTkDUhGc6Ot8jr7OH2kfL0fepCPin87A6Cw+bHgSewLXFiFPylhMAqWakagVAR9zOYWXbCcajSXYXcgvaQqw5j3v/8Oo2y20DQ+hsTgu78J2Il+8AQxfdg2dBZWITqgaVgLlJUDdsKSV2QnqmNnlpTFtS6gvGXvJnJUPDCZmxkuMohpZo69z1dy5c4MinbjXhGfhOJZvX05f6H7VIGIuB0GglIpEDeTNN998B43MY/nNRmu/P/a/4Ze0SakWJBf/efm38bs4NJD8ZvDbAyXiR7kQro9CDA0NrWL07Pg+JmlSEpBAAQmEDjR7JzI70CFbdKLfX8DstSQyLIZpPxruPQjKBCPW32kpcj3njsAtt9yykT7CXpT5DSnCHczJZRdT1mGjdtZsVUpwrSWQTaDUikQ060xn/4yX7V78ZoZvT9Cg3BZ1z8H9XSg7JyLfdBqCIX6PzIFMAxeBcvoUyxdc6znwklAACeSbALMTw6H+zLeU/ZGO9uM5GzduPJDOZeY+EpwfHRQKfiNI5nKn/hRPL1LZTFnWBkuT4l+M+0cp54+gUGR+3DEpsHYSyCJQGUUiCoHpwHMZ4d+NRifsEfkgvw1R9z7dh5mR39JRvmdo/PgtRtlJOyO6TyLlMxnWQD8dyZ6QT+mUSgISyBOBUJ/SacrsQOdJ3l7JsmXLlutRKMJSp2a+eDyPTuamoFQwC3xnr2Qy3t4RoP9w+/Dw8INIIW31QujvncTvIvZWHNQ7SYy5agQqqUhECnk7jc5L+S1kPf7O2P+A37aIe7dvwxdJzwkNHb+Z/A5Bobm224kUNT6+Nr08TXYauAto4B6e5q69BCQggRqB0IGmY/WWmrnK/2Fxd/L/rmYZMLi1KCgUE0pF4tr7ZuPSX38JrFq1aoR+xUNI9Vn81ieljmL5gLBBm/b0iUnu2kmgVQJOA7dKTP89JcCmsB+x9OzBaYlQAb6bDsLr0ty1Lz6B0IGp5YJOzVtRtt9cM/tfAq0SoMO0g+dovK2jE/VKOtZnthpHGfwvX778HgzWXDeBouUswW4V7HZtOWBGAMrmDOR5Vc1LGGSr3fu/MwIsCb47s/lfJ5as2Ye3w/yNnaVk6KoTqPqMRNXLP3f5R0k4nAbrTWmCoWScQuPzqzR37SUgAQlECYTZidBBDb+qKhGBx5o1a35P/sOyr29G+TR7T4d/l8hMxcpmw+lvMATYM3Q9z/whpJ618f6/KNPvTpxwORhBTbXwBFQkCl+E5csAjd3pbBR8TVrOaNDuNdGgvTDNj/bFJECD9vliSq7UEigGAerXxzOz+4JOpKUO3iOiVNzYSVyG7SmBHSgTz0F5fEVGKo9igO4GNmEfnuFHJwmkElCRSEWjwyAJsFHwvRzneFsDGT4cGrMGfnQuCAHOO/8lDdq/FURcxZRAYQkw8/vxMENDBr7TaSZQKvatKRX8/3Wn8Rm++wRQHj9AOQVFYV1K7EtQNq5gtj9L4UgJqnXVCahIVP0JyHH+mZrdjcrtU41EDI1YWAfdyJ/u+SVAGT504cKF986vhEomgfIRQJn4l6BQTCgVv+lCDu8ZUSq+3YX4jKJLBNhr9mPa0/2J7ntpUaJsvJ/yC0uhZqb50V4CcQIqEnEimnNFgJGUE5iGD8e/Zl5UgNNDA8bSmN9netQxdwSYiXg1Ql2eO8EUSAIVIoAyEb6zNK5U0OG8qQtZPzbUyWGQh9/HuhCfUXRIgPY0fKT30TSXb8uI6lmU228Y2Dkww49OEpgk4AkJkyi8yTOB+fPnb+WM7KFmZaQhfAV15gea9a+/wRGgkzFGw5YowMRIaaKblhKQQO8J8H7+hfdzz96nNG2a73s/KP89Dcr1iZRrUPBWpKQajo99EWXyuRR3rSUwTsAZCR+EQhAYGRkJX609EwWhqT0RVJBnUlGG5U5NKx+FAFEuIXfhiMItaUoEe2RSjwEuFwZzI4H8EmBAZq/QwQ8/qt9V+ZVUyVohQLlewJ60I6h/r0oJtxD7zzI78f9S3LWWwDiB5GFA4UggxwTmzZt3x+zZsxc3KyJLo8bYXKjS3CywPvkLih6NWGIdtH79+ms48/4+fRLFZCQggRYJ8P6u4fVd1mKwTO9BWcn0oGPXCXBa0yIUxKAshJO8ktrJjZTzQeyx+EvXEzfCUhBIemhKkTEzUV4CHA27U2hwGLHe3kwuGXUZ3z/B6PfNzfjXT+8JzJ07d3WaEkGjdq5KRO/LwBQk0AkBRrSXR2Yq7uokLsMOjgAKwl2U44uoj09CijsTJJnLYNzSBHutJDBOQEXCB6GwBDjVaRYdzsfT8WxquRNf+dw7jIKziey1hc10CQSnDM6fM2fO8qSsbN68eQ0dlOcmuWknAQnkkwDv7OIJpWIuEm7Mp5RKlUFgDIXiEygMR+Pntxn+dJLAFAJOI05BokURCTDbcCEzD8emjXLH80SFuWNoaGgnvvYaNpR59YkAJzT9DkXuoKTkgkJIh8TBjSQ42kmgYASokw+gTr6WOnm4GdF5/Y/j/f9qM3710zsClNtS6ulzKI+nTKTi0qbe4S5FzCoSpShGM1EjQCW4nZmHpjujo6OjG7jCpjKvHhPgaN6j6FhckpQMq9S2MMMUTg9RsUsCpJ0EJCCBPhJgk/XrSS78PsRsU/jvJYFEAioSiVi0LDqBrI28SXmjovwa9k9OctOucwKMcL2RmYjTk2Ji5GsaI5HWRUlwtJOABCQgAQnkmICNd44LR9E6I8AI+DGMgF/UTix0bsf3XYT/W7ZsWcna/b3biccwfycQPkyVxoITtV7CSrMPpblrLwEJSEACEpBAPgmoSOSzXJSqiwRQKL6KQvGkbkVZ0zFCfGGvxdatW49B0bisW/GXLJ694H8D/BO/5wHL+zAbcU3J8mx2JCABCUhAApUgoCJRiWI2k4FAq8ud2qVWUzT4P4aSMbJp06ZF7cZV9HBZzPlWxE84deuBRc+j8ktAAhKQgASqSkBFoqolX+F8Zy2z6TWWmpIR0gmzGWz2/giKxkt6nW5K/PcfHh4+j9Ordp3YoB4OvRqvEyb+RYMF+7Gae9ShzfuPsS8lnFvuJQEJSEACEpBAQQmoSBS04BS7MwKMlB9Bp/j7ncVi6HYIoDitZinYzu2ENYwEJCABCUhAAvkhoCKRn7JQkgEQYHbiiyT7jAEkXckkw3IvvxVRyaI30xKQgAQkUEICKhIlLFSz1DqBuXPn3sEyn4W1pTu1/63HZIg0AuyH2My+iMW4b03zo70EJCABCUhAAsUhoCJRnLJS0sERWMC1lm8h1E4eUs9osSyciWgRmN4lIAEJSEACBSAwqwAyKqIEBk0gfP16dpoQs2fPPo/fkzjidFwxV8uYSoqZCDdWT8WijQQkIAEJSKDQBJyRKHTxKXwRCMybN289JyPNm1AwCq1nhJkFmId6o+4Dc3+3Hi+N4GWMA6nGWMq0nk3V78Y2/LwkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQkIAEJSEACEpCABCQgAQlIQAISkIAEJCABCUhAAhKQgAQKQ+D/A6WQfraTizrFAAAAAElFTkSuQmCC',1,'2026-09-04 08:49:19','Auftragsbestaetigung202603.pdf','2026-09-04 08:49:19',NULL,'2026-09-04 07:23:41','2026-09-04 08:49:19');
/*!40000 ALTER TABLE `quote_confirmations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quotes`
--

DROP TABLE IF EXISTS `quotes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quotes` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `quote_number` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `amount_cents` mediumint NOT NULL,
  `quote_date` date NOT NULL,
  `customer_number` varchar(12) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `company_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `filename` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `meta` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `invoice_id` int unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `quote_number` (`quote_number`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quotes`
--

LOCK TABLES `quotes` WRITE;
/*!40000 ALTER TABLE `quotes` DISABLE KEYS */;
INSERT INTO `quotes` VALUES (3,'202601',20600,'2026-07-14','10016','TEST',3,'Angebot202601.pdf','{\"positions\":[{\"type\":\"custom\",\"title\":\"Upgrade Joomla! von  der aktuellen 5er auf die aktuelle 6er Version (einschl. Testlauf)\",\"qty\":1,\"price_cents\":20000,\"unit\":\"psch.\",\"position_number\":\"001\",\"position_source\":\"quote\"},{\"type\":\"custom\",\"title\":\"ab 2026 Pro: BackupMonkey (monatlich - hier zusätzliche Kosten je Quartal)\",\"qty\":3,\"price_cents\":200,\"unit\":\"Stck.\",\"position_number\":\"002\",\"position_source\":\"quote\"},{\"type\":\"custom\",\"title\":\"Alternativ: test\",\"qty\":5,\"price_cents\":600,\"unit\":\"Stck.\",\"position_number\":\"003\",\"position_source\":\"quote\"},{\"type\":\"custom\",\"title\":\"Eventual: e - Test\",\"qty\":0,\"price_cents\":30000,\"unit\":\"Stck.\",\"position_number\":\"004\",\"position_source\":\"quote\"}],\"texts\":{\"intro_header\":\"Sehr geehrte Damen und Herren,\\r\\nwir erlauben uns, wie folgt in Rechnung zu stellen:\",\"intro_items\":\"Angebotene Leistungen:\",\"footer\":\"Hinweis:\"}}',NULL,'2026-07-14 12:40:33','2026-07-14 12:59:35'),(4,'202602',500,'2026-07-14','10016','TEST',3,'Angebot202602.pdf','{\"positions\":[{\"type\":\"custom\",\"title\":\"Test\",\"qty\":1,\"price_cents\":500,\"unit\":\"Stck.\",\"position_number\":\"001\",\"position_source\":\"quote\"}],\"texts\":{\"intro_header\":\"Hello World\",\"intro_items\":\"Angebotene Leistungen: Test\",\"footer\":\"\"},\"email_sent\":true}',NULL,'2026-07-14 12:59:23','2026-07-16 13:11:30'),(5,'202603',3875,'2026-09-04','10015','vo.lan.di',2,'Angebot202603.pdf','{\"positions\":[{\"type\":\"catalog\",\"article_number\":\"mbb24-domain\",\"title\":\"Jährliche Domainkosten für mbb-24.de\",\"qty\":12,\"price_cents\":240,\"position_number\":\"001\",\"unit\":\"Stck.\",\"position_source\":\"quote\"},{\"type\":\"catalog\",\"article_number\":\"silber-datensicherung\",\"title\":\"Monatliche Datensicherung mit Akeeba BackupPro, einschl. automatisierter Speicherung aufexterner deutscher Qloud (Hetzner)\",\"qty\":1,\"price_cents\":995,\"position_number\":\"002\",\"unit\":\"Stck.\",\"position_source\":\"quote\"}],\"texts\":{\"intro_header\":\"Sehr geehrte Damen und Herren,\\r\\nwir erlauben uns, wie folgt anzubieten.\",\"intro_items\":\"Angebotene Leistungen:\",\"footer\":\"Hinweis: Test bitte mal bestätigen!\"},\"email_sent\":true}',NULL,'2026-09-04 07:23:41','2026-09-04 08:49:19');
/*!40000 ALTER TABLE `quotes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `receipts`
--

DROP TABLE IF EXISTS `receipts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `receipts` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `receipt_number` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `from_text` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `via_text` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `via2_text` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `to_text` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `time_text` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `waiting_time` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `agent` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `persons` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `price` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `receipt_date` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `vessel` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `signature_data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `receipt_number` (`receipt_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `receipts`
--

LOCK TABLES `receipts` WRITE;
/*!40000 ALTER TABLE `receipts` DISABLE KEYS */;
/*!40000 ALTER TABLE `receipts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schema_patches`
--

DROP TABLE IF EXISTS `schema_patches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schema_patches` (
  `id` varchar(64) NOT NULL,
  `applied_at` datetime NOT NULL,
  `message` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schema_patches`
--

LOCK TABLES `schema_patches` WRITE;
/*!40000 ALTER TABLE `schema_patches` DISABLE KEYS */;
INSERT INTO `schema_patches` VALUES ('sync_invoices_from_pdfs','2026-08-25 05:59:14','0 importiert, 0 aktualisiert, 64 übersprungen, 3 weitere auf bezahlt gesetzt. Hinweise: 2019060002ihrtaxi-hamburg.pdf: Nummer, Datum oder Betrag nicht lesbar. 2020010002ihrtaxi-hamburg.pdf: Nummer, Datum oder Betrag nicht lesbar. 2020060002ihrtaxi-hamburg.pdf: Nummer, Datum oder Betrag nicht lesbar. 2021010001ihrtaxi-hamburg.pdf: Nummer, Datum oder Betrag nicht lesbar. 2022010001ihrtaxi-hamburg.pdf: Nummer, Datum oder Betrag nicht lesbar. …'),('sync_invoices_from_pdfs_v4','2026-08-25 10:10:45','52 importiert, 7 aktualisiert, 0 übersprungen, 0 weitere auf bezahlt gesetzt.');
/*!40000 ALTER TABLE `schema_patches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `text_blocks`
--

DROP TABLE IF EXISTS `text_blocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `text_blocks` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `text_key` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `note` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `meta` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `text_key` (`text_key`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `text_blocks`
--

LOCK TABLES `text_blocks` WRITE;
/*!40000 ALTER TABLE `text_blocks` DISABLE KEYS */;
INSERT INTO `text_blocks` VALUES (1,'vor1','Sehr geehrte Damen und Herren,\r\nwir erlauben uns, wie folgt in Rechnung zu stellen:',1,'Anrede',NULL,'2026-07-06 10:23:15','2026-07-06 10:23:15'),(2,'schluss1','Sofern nicht anders angegeben, entspricht das Liefer-/Leistungsdatum dem Rechnungsdatum. \r\nZahlungsbedingungen: innerhalb von 14 Werktagen netto Kasse\r\nIn dieser Rechnung ist gemäß der Kleinunternehmer-Regelung (§19 Abs. 1 UStG) keine Umsatzsteuer enthalten und ausgewiesen.',1,'Standard',NULL,'2026-07-06 10:23:15','2026-07-06 11:30:49'),(5,'hin1','Hinweis:',1,'Text erscheint direkt vor den Rechnungsartikeln in der Tabelle ()',NULL,'2026-07-06 10:23:15','2026-07-06 10:23:15'),(6,'hin-silber','Wartungsvertrag Nr. 02/25 Automatische vierteljährliche Verlängerung, Kündigung: 1 Monat zum Laufzeitende. \r\n\r\nHier: 3. Quartal 01.10.2026 bis 31.12.2026',1,'silberring-Wartungsvertrag',NULL,'2026-07-06 10:23:15','2026-07-06 11:40:18'),(7,'hin-taxi','Projekt-Domain: https://rechnung.ihr-taxi-hamburg.de Individuelle Buchhaltung mit Kassenbuch,\r\nRechnung und Wallet. Auswertungen für den Steuerberater',1,'ihrtaxi-Projekt',NULL,'2026-07-06 10:23:15','2026-07-06 11:40:43'),(8,'hin-mbb-24','Wartungsvertrag Nr. 01/18 (Vertragslaufzeit 1 Jahr). \r\nAutomatische jährliche Verlängerung!\r\nKündigung 1 Monat zum Quartalsende.\r\n\r\nHier: 4. Quartale: 01.01.2027 bis 31.12.2027',1,'mbb24 - Wartungsvertrag',NULL,'2026-07-06 10:23:15','2026-07-06 11:42:51');
/*!40000 ALTER TABLE `text_blocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` tinyint(1) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `first_name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `last_name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `rights` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT 'tz67',
  `selection` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL COMMENT 'not used',
  PRIMARY KEY (`id`),
  UNIQUE KEY `userername` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'wumy','$2y$10$qHgW2bcQDG/k/0t30JWe.OvlcT8NkTA3kMiZbRkTCEc7ZC/aoGBD6','Marko','Jorissen','2026-07-16 12:38:14','2023-05-07 09:27:40','superadmin','2025'),(2,'demo','$2y$10$9K2xGA8ByQU7.qceRYgsNu4Sr56NlC/JZpLX9SbZysMQMXPWIiOuq','Max','Tester','2026-07-28 13:15:06','2026-07-16 11:52:03','demo',NULL),(3,'hansen','$2y$10$Ll5UI3nEl50EaxbT.P65FuieGTtXO4bWLddnGSzQlQx.XucbtykGC','Hermann','Hansen','2026-09-04 05:21:17','2026-07-31 07:54:53','demo',NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-05 15:19:10
